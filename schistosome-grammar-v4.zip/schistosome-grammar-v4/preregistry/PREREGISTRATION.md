# Pre-registration: Schistosome Grammar Rehearsal Registry & Resistance Surveillance Prediction

Created: 2026-09-27 (frozen document; SHA-256 recorded in preregistry.sha256)
Status: manuscript-appendix pre-registration; OSF/Zenodo DOI to be assigned by the authors upon submission (document hash serves as the interim integrity anchor).

## Part A — Rehearsal registry rules (frozen)

R1. Trigger: any newly documented schistosome hybrid zone, hybrid outbreak, or novel-area establishment event, on publication of a primary report.
R2. Deadline: the event is scored blind within 72 h of the report, using the panel data frozen at the report date; the scoring script version and data snapshot hash are archived with the score.
R3. Estimators (all reported, no selection after the fact): (i) gradient boosting, (ii) L1 logistic, (iii) nearest-neighbour in standardized descriptor space, (iv) temperature-scaled gradient boosting (official calibrated posterior).
R4. Abstention: if the event is clade-novel relative to the frozen panel, the registry records ABSTAIN, not a score.
R5. Scores are immutable once archived; post-hoc model changes create a new entry, never overwrite.

## Part B — Archived blind scores (as of 2026-09-27, n=22 supervised panel)

| Event | Truth | GB | logistic | NN | temperature-scaled GB |
|---|---|---|---|---|---|
| Corsica 2013 (Sh x Sb) | 1 | 0.07 | 0.12 | 1.00 | 0.03 |
| Senegal zone (Sh x Sc) | 1 | 1.00 | 0.13 | 1.00 | 0.16 |
| Niger Inner Delta (Sh x Sb) | 0 | 0.07 | 0.12 | 1.00 | 0.03 |
| Cameroon Lower Guinea (Sh x Si) | 1 | 0.00 | 0.09 | 0.00 | 0.00 |
| Guadeloupe (Sm x Sr) | 1 | 0.00 | 0.14 | 0.00 | 0.00 |
| Real Sb x Sc mitogenome | 0 | 0.00 | 0.26 | 1.00 | 0.00 |

Recorded verdict at freeze: under the official calibrated estimator the grammar is abstention-leaning on all six events; the nearest-neighbour rule reads 3/6. The registry exists to convert every future event into a free, falsifying test of the calibrated grammar.

## Part C — Falsifiable resistance-surveillance prediction (frozen)

C1. Prediction: in a persistence hotspot with sustained effective praziquantel coverage u > 0.60 for >= 5 consecutive years and genetically uniform drug pressure, a circulating TRPM_PZQ allele with relative activity RA < 0.5 will be documented within 5 years of the coverage threshold being crossed.
C2. Complementary prediction: in regions with u < 0.40 over the same window, no such allele will be documented (boundary s* = bu/(1-u) excludes low-cost fixation at WHO 2024 global coverage u = 0.396).
C3. Verification data: TRPtracker updates (community resource), WHO PCT coverage reports. Every TRPtracker release is a free natural experiment against C1/C2.
C4. Failure mode: if a RA < 0.5 allele appears under sustained u < 0.40, the invasion-boundary model is falsified for that setting and the b-s parameterisation must be revised.
