# Pipeline map

| Script | Experiment | Output |
|---|---|---|
| e10_fetch_mt.py / e10_candidates.py / e10_select.py / e10_download.py | NCBI/ENA search & download of 23 mitochondrial sequences | data/fasta/ |
| e10_analysis.py | sequence descriptors, Markov budget (V0), distance matrix | results/e10_markov.json, e10_dist.json |
| e10b_adjudication.py | LOSO + paired bootstrap Delta R (risk form) + power | results/e10_adjudication.json, e16_power.json |
| e20_stats_upgrade.py | exact paired permutation, clade-cluster bootstrap, convergence curve | results/e20_stats_upgrade.json |
| e21_estimators_nn.py | nested temperature scaling (official estimator), ECE, NN baseline, 6 rehearsals | results/e21_estimators_nn.json |
| e22_baselines.py | estimator suite (GB/RF/L2/kNN/NB) on identical folds | results/e22_baselines.json |
| e11_download_string.py / e11_network2.py | STRING v12.0 bulk download (resume) + topology descriptors | results/e11_string_topology.json |
| e13_climate_v4.py | daily ERA5 integration, precipitation gate, AR6 ensemble bands | results/e23_climate_v4.json |
| e24_paleo_v4.py | 17 anchors, weighted Beta posteriors, import sensitivity | results/e24_paleo_v4.json |
| e25_budget_table.json | viral-vs-schistosome budget comparison (Table 2 source) | results/e25_budget_table.json |
| master_numbers.py | single numeric source for the manuscript | results/master_numbers.json |
| build_v4_text.py / build_v4_text2.py | manuscript text generation with injected numbers | results/manuscript_v4_text*.json |
| figures.py / ed_figures.py / figures_v4.py / fig1_schematic.py | all figures | figures/ |
| build_docx_v4.py | pandoc -> native OMML docx -> schema fixes -> lxml XSD validation (target: 0 errors) | manuscript/*.docx |
