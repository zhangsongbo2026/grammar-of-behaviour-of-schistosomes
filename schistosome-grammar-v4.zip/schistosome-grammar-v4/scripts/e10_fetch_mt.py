#!/usr/bin/env python3
"""E10: fetch complete mitochondrial genomes for schistosome panel expansion.
Real data from NCBI nuccore via E-utilities."""
import json, subprocess, time, urllib.request, urllib.parse

def esearch(term, retmax=200):
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?" + urllib.parse.urlencode({
        "db": "nuccore", "term": term, "retmax": retmax, "retmode": "json", "usehistory": "y"})
    with urllib.request.urlopen(url, timeout=30) as r:
        d = json.loads(r.read())
    return d["esearchresult"]

res = esearch('Schistosomatidae[Organism] AND mitochondrion[Filter] AND "complete genome"[Title]')
ids = res.get("idlist", [])
print("hits:", res.get("count"), "returned:", len(ids))
json.dump(ids, open("data/mt_search_ids.json", "w"))
