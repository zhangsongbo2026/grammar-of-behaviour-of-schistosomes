import gzip, os, subprocess, time
TAX = ["6182","6183","6184","6185","6186","6188","31246","48269"]
BASE = "https://stringdb-downloads.org/download/protein.links.detailed.v12.0"
def gz_ok(p):
    try:
        with gzip.open(p,"rt") as f:
            for _ in f: pass
        return True
    except Exception: return False
for t in TAX:
    p = f"data/string/{t}.protein.links.detailed.v12.0.txt.gz"
    for attempt in range(12):
        if gz_ok(p):
            print(t, "OK", os.path.getsize(p), flush=True); break
        # resume
        cmd = ["curl","-sL","-m","600","-C","-","-o",p,f"{BASE}/{t}.protein.links.detailed.v12.0.txt.gz"]
        subprocess.run(cmd, capture_output=True)
        print(t, "attempt", attempt, os.path.getsize(p), flush=True)
        time.sleep(2)
