#!/usr/bin/env python3
"""E15: blind hybrid-emergence rehearsals with three events — Corsica (S. haematobium
x S. bovis, parental mean), Senegal (S. haematobium x S. curassoni, parental mean),
and a REAL hybrid mitogenome (S. bovis x S. curassoni, PV535797). Plus introgression
sensitivity sweep m in [0,1]."""
import csv, json, math, itertools
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score

rng = np.random.default_rng(7)
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]; k4s = np.array(dist["k4s"])
BASE_KEYS = ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")

def read_seq(t):
    return "".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()

def base_vector_t(t):
    seq = read_seq(t); n=len(seq)
    a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    at=(a-tt)/(a+tt); gcs=(g-c)/(g+c)
    obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([dist["gc"][t], at, gcs] + [odds[k] for k in BASE_KEYS])

def k4vec(seq):
    n=len(seq); k4=Counter(seq[i:i+4] for i in range(n-3))
    v=np.zeros(256)
    for i,k in enumerate(["".join(p) for p in itertools.product("ACGT",repeat=4)]):
        v[i]=k4.get(k,0)
    return v/(n-3)

k4s_t1 = k4s[[i for i,t in enumerate(TAXES) if PANEL[t]["tier"]=="tier1"]]
mean = k4s_t1.mean(0); std = k4s_t1.std(0)+1e-12
U,S,Vt = np.linalg.svd((k4s_t1-mean)/std*1.0, full_matrices=False)
comp = Vt[:5]; mu = (k4s_t1-mean).mean(0); med = np.median((k4s_t1-mean)@comp.T, axis=0)
def pca5_seq(seq):
    z = (k4vec(seq)-mean)/std
    return (z-mean*0) @ comp.T if False else z @ comp.T

def feats_full(seq_or_tax, tier=None):
    if isinstance(seq_or_tax, str) and seq_or_tax in TAXES:
        t = seq_or_tax
        b = base_vector_t(t)
        p = ((k4s[TAXES.index(t)]-mean)/std) @ comp.T if PANEL[t]["tier"]=="tier1" else med
    else:
        seq = seq_or_tax
        a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
        n=len(seq)
        at=(a-tt)/(a+tt); gcs=(g-c)/(g+c); gc_=(g+c)/n
        obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
        odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
        b = np.array([gc_, at, gcs] + [odds[k] for k in BASE_KEYS])
        p = pca5_seq(seq)
    return np.concatenate([b, p])

def feats_eco_of(r):
    gens = ["Biomphalaria","Bulinus","Oncomelania","Neotricula","Indoplanorbis","Radix","Tricula","unknown"]
    zones = ["tropical","subtropical","temperate"]
    return np.array([1.0 if r["snail_genus"]==g else 0.0 for g in gens] +
                    [1.0 if r["climate_zone"]==z else 0.0 for z in zones])

def feats_seq_only(x): return feats_full(x)
def feats_comb_x(x, eco):
    return np.concatenate([feats_full(x), eco])

supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]
yv = {t: int(PANEL[t]["human_infecting"]) for t in supervised}

def train_model(taxes, feats, est="gb"):
    X = np.array([feats[t] for t in taxes]); y=[yv[t] for t in taxes]
    if est=="gb": m = GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
    else: m = LogisticRegression(C=1.0,solver="liblinear",random_state=42,max_iter=5000)
    m.fit(X,y); return m

EVENTS = {
  "Corsica_2013 (Sh x Sb)": {"parents": ["Schistosoma haematobium","Schistosoma bovis"],
      "eco": {"snail_genus":"Bulinus","climate_zone":"temperate"}, "truth": 1},
  "Senegal_zone (Sh x Sc)": {"parents": ["Schistosoma haematobium","Schistosoma curassoni"],
      "eco": {"snail_genus":"Bulinus","climate_zone":"tropical"}, "truth": 1},
  "Real hybrid mito (Sb x Sc, PV535797)": {"seq": read_seq("Hybrid_S.bovis_x_S.curassoni"),
      "eco": {"snail_genus":"Bulinus","climate_zone":"tropical"}, "truth": 0},
}
res = {}
for name, ev in EVENTS.items():
    p1, p2 = ev.get("parents", [None, None])
    eco = feats_eco_of(ev["eco"])
    # descriptor: parental mean (real seq events use their own sequence)
    if "seq" in ev:
        f = feats_full(ev["seq"])
    else:
        s1, s2 = read_seq(p1), read_seq(p2)
        f = (feats_full(s1) + feats_full(s2)) / 2.0
    x_seq = f; x_comb = np.concatenate([f, eco])
    for mode, drop in (("in-clade", p1 if p1 else None), ("de novo", "CLADE")):
        if mode == "in-clade":
            if p1:  # parental-mean events: withhold both parents
                taxes = [t for t in supervised if t not in (p1, p2)]
            else:   # real hybrid: withhold bovis and curassoni
                taxes = [t for t in supervised if t not in ("Schistosoma bovis","Schistosoma curassoni")]
        else:
            if p1:  # de novo: withhold entire haematobium clade
                taxes = [t for t in supervised if PANEL[t]["clade"] != "haematobium"]
            else:
                taxes = [t for t in supervised if PANEL[t]["clade"] != "haematobium"]
        m_gb = train_model(taxes, {t: feats_seq_only(t) for t in taxes})
        p_seq = float(m_gb.predict_proba(np.array([x_seq]))[0][1])
        m_gb2 = train_model(taxes, {t: feats_comb_x(t, feats_eco_of(PANEL[t])) for t in taxes})
        p_comb = float(m_gb2.predict_proba(np.array([x_comb]))[0][1])
        m_lg = train_model(taxes, {t: feats_seq_only(t) for t in taxes}, "log")
        p_log = float(m_lg.predict_proba(np.array([x_seq]))[0][1])
        abstain = (mode=="de novo")
        res[f"{name}|{mode}"] = {"P_human_seq": round(p_seq,2), "P_human_combined": round(p_comb,2),
            "P_human_logistic": round(p_log,2), "truth": ev["truth"], "abstains": abstain,
            "n_train": len(taxes)}
print(json.dumps(res, indent=1))
json.dump(res, open("results/e15_rehearsals.json","w"), indent=1)

# introgression sensitivity: hybrid descriptor = (1-m)*Sh + m*Sb, m in [0,1]
sens = {}
s1, s2 = read_seq("Schistosoma haematobium"), read_seq("Schistosoma bovis")
f1_, f2_ = feats_full(s1), feats_full(s2)
eco_h = feats_eco_of({"snail_genus":"Bulinus","climate_zone":"temperate"})
eco_b = feats_eco_of({"snail_genus":"Bulinus","climate_zone":"tropical"})
taxes = [t for t in supervised if t not in ("Schistosoma haematobium","Schistosoma bovis")]
m_gb = train_model(taxes, {t: feats_seq_only(t) for t in taxes})
for m_ in np.linspace(0,1,11):
    f = (1-m_)*f1_ + m_*f2_
    eco = (1-m_)*eco_h + m_*eco_b
    p1 = float(m_gb.predict_proba(np.array([f]))[0][1])
    m_gb2 = train_model(taxes, {t: feats_comb_x(t, feats_eco_of(PANEL[t])) for t in taxes})
    p2v = float(m_gb2.predict_proba(np.array([np.concatenate([f, eco])]))[0][1])
    sens[round(float(m_),2)] = {"P_seq": round(p1,2), "P_comb": round(p2v,2)}
print("SENSITIVITY:", json.dumps(sens))
json.dump(sens, open("results/e15_introgression.json","w"), indent=1)
