#!/usr/bin/env python3
"""P0-2: statistical upgrade of the core adjudication —
(a) exact paired permutation test over LOSO taxa (swap method/baseline per taxon),
(b) clade-level cluster bootstrap -> P(Delta R > 0),
(c) Delta R convergence curve vs n (subsample),
(d) power: n needed for 80% exclusion at observed effect size."""
import csv, json, itertools
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import f1_score

rng = np.random.default_rng(2026)
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]; k4s = np.array(dist["k4s"])
supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]
BASE_KEYS = ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")

def base_vector(t):
    seq = "".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()
    n=len(seq); a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    at=(a-tt)/(a+tt); gcs=(g-c)/(g+c); gc_=(g+c)/n
    obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([gc_, at, gcs] + [odds[k] for k in BASE_KEYS])

def pca5_for(t):
    idx = TAXES.index(t)
    tier1 = [i for i,x in enumerate(TAXES) if PANEL[x]["tier"]=="tier1"]
    X = k4s[tier1]; mean = X.mean(0)
    U,S,Vt = np.linalg.svd(X-mean, full_matrices=False)
    comp = Vt[:5]
    med = np.median((k4s[tier1]-mean)@comp.T, axis=0)
    if PANEL[t]["tier"]=="tier1": return (k4s[idx]-mean)@comp.T
    return med
PCA5 = {t: pca5_for(t) for t in TAXES}
def feats_base(t): return base_vector(t)
def feats_all(t): return np.concatenate([base_vector(t), PCA5[t]])

def target_y(t, target):
    return int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"]

def loso_scores(taxes, bfn, target, est="gb"):
    yv = {t: target_y(t, target) for t in taxes}
    out=[]
    for held in taxes:
        tr=[t for t in taxes if t!=held]
        Xtr=np.array([bfn(t) for t in tr]); ytr=[yv[t] for t in tr]
        m = GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
        m.fit(Xtr,ytr)
        p=m.predict(np.array([bfn(held)]))[0]
        out.append((held,p,yv[held]))
    return out

def b_tax_scores(taxes, target):
    yv={t: target_y(t,target) for t in taxes}
    yp,yt=[],[]
    for held in taxes:
        tr=[t for t in taxes if t!=held]
        yp.append(Counter(yv[t] for t in tr).most_common(1)[0][0]); yt.append(yv[held])
    return yt, yp

def mF1(yt,yp): return f1_score(list(yt),list(yp),average="macro")

def deltaR_from(ytrue,ypred,yt,yp):
    f1=mF1(ytrue,ypred); ftax=mF1(yt,yp)
    if 1-ftax==0: return np.nan
    return 1-(1-f1)/(1-ftax)

results={}
for target in ("host_range","human"):
    sc = loso_scores(supervised, feats_base, target)
    ytrue=[s[2] for s in sc]; ypred=[s[1] for s in sc]
    yt,yp = b_tax_scores(supervised, target)
    dr_obs = deltaR_from(ytrue,ypred,yt,yp)
    # (a) exact-ish paired permutation: swap (method, baseline) per taxon, 2^22 -> 200k samples
    n=len(supervised); swaps = rng.random((200000,n))<0.5
    null=[]
    ytrue_a=np.array(ytrue); ypred_a=np.array(ypred); yt_a=np.array(yt); yp_a=np.array(yp)
    for row in swaps[:20000]:
        m2 = np.where(row, ypred_a, yp_a); b2 = np.where(row, yp_a, ypred_a)
        d = deltaR_from(ytrue_a, m2, ytrue_a, b2)
        if not np.isnan(d): null.append(d)
    null=np.array(null)
    p_perm = float((np.sum(np.abs(null-np.mean(null))>=np.abs(dr_obs-np.mean(null)))+1)/(len(null)+1))
    p_one = float((np.sum(null>=dr_obs)+1)/(len(null)+1))
    # (b) clade-level cluster bootstrap
    clades=[PANEL[t]["clade"] for t in supervised]
    ucl=sorted(set(clades)); vals=[]
    for _ in range(10000):
        pick=[ucl[i] for i in rng.integers(0,len(ucl),len(ucl))]
        idx=[i for c in pick for i,cc in enumerate(clades) if cc==c]
        if len(set(idx))<6: continue
        d=deltaR_from([ytrue[i] for i in idx],[ypred[i] for i in idx],[yt[i] for i in idx],[yp[i] for i in idx])
        if not np.isnan(d): vals.append(d)
    vals=np.array(vals)
    p_pos=float((vals>0).mean())
    # taxon bootstrap P(DeltaR>0)
    tv=[]
    for _ in range(10000):
        idx=rng.integers(0,n,n)
        d=deltaR_from([ytrue[i] for i in idx],[ypred[i] for i in idx],[yt[i] for i in idx],[yp[i] for i in idx])
        if not np.isnan(d): tv.append(d)
    tv=np.array(tv)
    p_pos_taxon=float((tv>0).mean())
    results[target]={"deltaR":round(float(dr_obs),3),
        "permutation_p_two_sided":round(p_perm,4),
        "permutation_p_greater":round(p_one,4),
        "clade_cluster_boot_ci":[round(float(np.quantile(vals,0.025)),3),round(float(np.quantile(vals,0.975)),3)],
        "P_deltaR_gt0_clade":round(p_pos,3),
        "taxon_boot_ci":[round(float(np.quantile(tv,0.025)),3),round(float(np.quantile(tv,0.975)),3)],
        "P_deltaR_gt0_taxon":round(p_pos_taxon,3)}
    print(target, results[target], flush=True)

# (c) convergence curve: subsample taxa, compute CI width of DeltaR (host_range, z_seq_base)
conv={}
for nsub in range(10, 23, 2):
    widths=[]
    for rep in range(60):
        sub=[supervised[i] for i in rng.choice(len(supervised), nsub, replace=False)]
        sc=loso_scores(sub, feats_base, "host_range")
        ytrue=[s[2] for s in sc]; ypred=[s[1] for s in sc]
        yt,yp=b_tax_scores(sub,"host_range")
        tv=[]
        for _ in range(300):
            idx=rng.integers(0,nsub,nsub)
            d=deltaR_from([ytrue[i] for i in idx],[ypred[i] for i in idx],[yt[i] for i in idx],[yp[i] for i in idx])
            if not np.isnan(d): tv.append(d)
        tv=np.array(tv)
        widths.append(np.quantile(tv,0.975)-np.quantile(tv,0.025))
    conv[nsub]={"mean_width":round(float(np.mean(widths)),3),"sd":round(float(np.std(widths)),3)}
    print("n",nsub,"width",conv[nsub], flush=True)
results["convergence"]=conv

# (d) power: n needed for 80% exclusion at observed effect (+0.303) using convergence fit
ws=[(n,c["mean_width"]) for n,c in conv.items()]
import numpy.polynomial.polynomial as P
fit=np.polyfit([n for n,_ in ws],[w for _,w in ws],1)
results["power_fit"]={"slope":round(float(fit[0]),4),"intercept":round(float(fit[1]),3),
  "n_for_width_0.15": int(np.ceil((0.15-fit[1])/fit[0])) if fit[0]<0 else None}
print("POWER FIT:", results["power_fit"])
json.dump(results, open("results/e20_stats_upgrade.json","w"), indent=1)
print("saved")
