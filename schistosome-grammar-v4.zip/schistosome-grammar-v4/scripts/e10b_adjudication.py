#!/usr/bin/env python3
"""Corrected paired-bootstrap adjudication (risk-based ΔR), V2-14 continuity subset,
power analysis, and three-event hybrid rehearsals with a real hybrid mitogenome."""
import csv, json, math, itertools
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score

rng = np.random.default_rng(42)
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]
k4s = np.array(dist["k4s"])

BASE_KEYS = ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")
def base_vector(t):
    f_gc = dist["gc"][t]
    # recompute skews+odds from raw fasta
    import math as m
    seq = "".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()
    n=len(seq); a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    at=(a-tt)/(a+tt); gc_=(g-c)/(g+c)
    obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([f_gc, at, gc_] + [odds[k] for k in BASE_KEYS])

def pca5_for(t, tax_list, k4s):
    idx = tax_list.index(t)
    tier1 = [i for i,x in enumerate(tax_list) if PANEL[x]["tier"]=="tier1"]
    X = k4s[tier1]; mean = X.mean(0)
    U,S,Vt = np.linalg.svd(X-mean, full_matrices=False)
    med = np.median((k4s[tier1]-mean)@Vt[:5].T, axis=0)
    if PANEL[t]["tier"]=="tier1":
        return (k4s[idx]-mean)@Vt[:5].T
    return med
PCA5 = {t: pca5_for(t, TAXES, k4s) for t in TAXES}

def feats_all(t): return np.concatenate([base_vector(t), PCA5[t]])
def feats_base(t): return base_vector(t)
def feats_eco(t):
    r = PANEL[t]
    gens = ["Biomphalaria","Bulinus","Oncomelania","Neotricula","Indoplanorbis","Radix","Tricula","unknown"]
    zones = ["tropical","subtropical","temperate"]
    return np.array([1.0 if r["snail_genus"]==g else 0.0 for g in gens] +
                    [1.0 if r["climate_zone"]==z else 0.0 for z in zones])
def feats_comb(t): return np.concatenate([feats_all(t), feats_eco(t)])
BLOCKS = {"z_seq": feats_all, "z_seq_base": feats_base, "z_eco": feats_eco, "combined": feats_comb}

supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]
V2_14 = ["Schistosoma mansoni","Schistosoma rodhaini","Schistosoma haematobium","Schistosoma bovis",
 "Schistosoma curassoni","Schistosoma intercalatum","Schistosoma guineensis","Schistosoma mattheei",
 "Schistosoma margrebowiei","Schistosoma japonicum","Schistosoma mekongi","Schistosoma spindale",
 "Schistosoma turkestanicum","Trichobilharzia regenti"]

def target_y(t, target):
    return int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"]

def loso_scores(taxes, bfn, target, est):
    yv = {t: target_y(t, target) for t in taxes}
    out = []
    for held in taxes:
        tr = [t for t in taxes if t != held]
        Xtr = np.array([bfn(t) for t in tr]); ytr=[yv[t] for t in tr]
        if est=="gb":
            m = GradientBoostingClassifier(n_estimators=100, max_depth=2, random_state=42)
        else:
            m = LogisticRegression(C=1.0, solver="liblinear", random_state=42, max_iter=5000)
        try:
            m.fit(Xtr, ytr); p = m.predict(np.array([bfn(held)]))[0]
        except Exception:
            p = Counter(ytr).most_common(1)[0][0]
        out.append((held, p, yv[held]))
    return out

def mF1(yt, yp): return f1_score(list(yt), list(yp), average="macro")

def b_tax_scores(taxes, target):
    yv = {t: target_y(t, target) for t in taxes}
    yp, yt = [], []
    for held in taxes:
        tr=[t for t in taxes if t!=held]
        yp.append(Counter(yv[t] for t in tr).most_common(1)[0][0]); yt.append(yv[held])
    return yt, yp

def b_fam_scores(taxes, target):
    yv = {t: target_y(t, target) for t in taxes}
    maj = Counter(yv.values()).most_common(1)[0][0]
    return list(yv.values()), [maj]*len(yv)

def deltaR(target, bname, est, taxes, n_boot=10000):
    sc = loso_scores(taxes, BLOCKS[bname], target, est)
    ytrue = [s[2] for s in sc]; ypred=[s[1] for s in sc]
    yt, yp = b_tax_scores(taxes, target)
    f1 = mF1(ytrue, ypred); ftax = mF1(yt, yp)
    rm, rb = 1-f1, 1-ftax
    point = 1 - rm/rb if rb>0 else np.nan
    lo=[]
    for _ in range(n_boot):
        idx = rng.integers(0,len(ytrue),len(ytrue))
        a = mF1([ytrue[i] for i in idx],[ypred[i] for i in idx])
        b = mF1([yt[i] for i in idx],[yp[i] for i in idx])
        if 1-b == 0: continue
        lo.append(1-(1-a)/(1-b))
    return {"f1":round(float(f1),3),"f1_Btax":round(float(ftax),3),
            "deltaR":round(float(point),3),
            "ci":[round(float(np.nanquantile(lo,0.025)),3), round(float(np.nanquantile(lo,0.975)),3)]}

out = {"supervised_n": len(supervised)}
for target in ("host_range","human"):
    for bname in ("z_seq","z_seq_base","z_eco","combined"):
        out[f"n22|{target}|{bname}|gb"] = deltaR(target, bname, "gb", supervised)
        out[f"n22|{target}|{bname}|log"] = deltaR(target, bname, "log", supervised, n_boot=4000)
    # baselines
    yt,yp = b_tax_scores(supervised, target); yf,yfp = b_fam_scores(supervised, target)
    out[f"n22|{target}|B_tax"] = {"f1": round(float(mF1(yt,yp)),3)}
    out[f"n22|{target}|B_fam"] = {"f1": round(float(mF1(yf,yfp)),3)}
    # V2-14 continuity
    for bname in ("z_seq","combined"):
        out[f"v2n14|{target}|{bname}|gb"] = deltaR(target, bname, "gb", V2_14, n_boot=4000)
    yt,yp = b_tax_scores(V2_14, target); yf,yfp = b_fam_scores(V2_14, target)
    out[f"v2n14|{target}|B_tax"] = {"f1": round(float(mF1(yt,yp)),3)}
    out[f"v2n14|{target}|B_fam"] = {"f1": round(float(mF1(yf,yfp)),3)}
print(json.dumps(out, indent=1))
json.dump(out, open("results/e10_adjudication.json","w"), indent=1)

# ---------- power analysis ----------
# permutation-based power: how often does the n22 ΔR bootstrap CI exclude zero if true deltaR = observed?
pw = {}
for target in ("host_range","human"):
    for n in (14, 22):
        taxes = supervised if n==22 else V2_14
        sc = loso_scores(taxes, BLOCKS["z_seq"], target, "gb")
        ytrue=[s[2] for s in sc]; ypred=[s[1] for s in sc]
        yt,yp = b_tax_scores(taxes, target)
        f1=mF1(ytrue,ypred); ftax=mF1(yt,yp)
        rm, rb = 1-f1, 1-ftax
        dtrue = 1-rm/rb if rb>0 else 0
        excl = 0
        for _ in range(300):
            idx = rng.integers(0,len(ytrue),len(ytrue))
            a=mF1([ytrue[i] for i in idx],[ypred[i] for i in idx]); b=mF1([yt[i] for i in idx],[yp[i] for i in idx])
            if 1-b==0: continue
            d = 1-(1-a)/(1-b)
            if d > 0 and dtrue > 0: excl += 1
            elif d <= 0 and dtrue <= 0: excl += 1
        pw[f"{target}|n{n}"] = {"point_deltaR": round(float(dtrue),3), "ci_excl_zero_rate": round(excl/300,3)}
print("POWER:", json.dumps(pw))
json.dump(pw, open("results/e16_power.json","w"), indent=1)
