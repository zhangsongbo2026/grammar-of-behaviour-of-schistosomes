#!/usr/bin/env python3
"""V4 figure updates: Fig4 (ensemble interval), Fig5 (6 events x 4 estimators),
ED7 convergence curve, ED8 baseline suite, ED9 palaeo weighted."""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":7.5,"axes.titlesize":8,
 "axes.linewidth":0.6,"pdf.fonttype":42,"legend.fontsize":6.5,"legend.frameon":False,
 "xtick.major.size":2.5,"ytick.major.size":2.5})
CB={"blue":"#3B6FB6","orange":"#E8853D","green":"#4F9C6B","red":"#C4453C",
    "purple":"#7E57A5","teal":"#2B9C93","grey":"#8C8C8C","yellow":"#C9A83A"}
M=json.load(open("results/master_numbers.json"))
def pl(ax,s,dx=-0.14): ax.text(dx,1.05,s,transform=ax.transAxes,fontsize=9,fontweight="bold",va="top")

# ===== Fig4: ensemble version =====
fig,axes=plt.subplots(1,3,figsize=(7.1,2.6))
def R0T(T):
    if T<15.4: return 0.0
    if T<20: return 0.70*(T-15.4)/4.6
    if T<=27: return 1.0
    if T<=30: return 1.0-0.60*(T-27)/3
    if T<=33: return 0.40-0.37*(T-30)/3
    if T<=35: return 0.03-0.024*(T-33)/2
    return 0.006
ax=axes[0]
T=np.linspace(10,40,400)
ax.plot(T,[R0T(t) for t in T],color=CB["blue"],lw=1.4)
for x_,y_ in ((15.4,0.0),(20,0.70),(33,0.03),(35,0.006)):
    ax.scatter([x_],[y_],s=14,color=CB["red"],zorder=5)
ax.axvspan(22,27,color=CB["green"],alpha=0.15)
ax.text(24.5,0.85,"22–27 °C\nwindow",ha="center",fontsize=6)
ax.set_xlabel("temperature (°C)"); ax.set_ylabel("relative R$_0$(T)")
ax.set_ylim(-0.05,1.1); pl(ax,"a")

ax=axes[1]
sites=["Yueyang_Dongting_CN","Anxiang_Dongting_CN","Guichi_Anhui_CN","RichardToll_Senegal","Mwache_Kenya","Ukerewe_Tanzania"]
short=["Yueyang","Anxiang","Guichi","Rich.-Toll","Mwache","Ukerewe"]
d=M["climate"]["daily"]
xs=np.arange(6); w=0.38
b90=[d[s]["daily_pot_baseline_1990_2000"] for s in sites]
b20=[d[s]["daily_pot_2015_2025"] for s in sites]
ax.bar(xs-w/2,b90,w,color=CB["blue"],label="1990–2000")
ax.bar(xs+w/2,b20,w,color=CB["red"],label="2015–2025")
ax.set_xticks(xs); ax.set_xticklabels(short,rotation=45,ha="right",fontsize=6)
ax.set_ylabel("observed annual potential\n(daily ERA5 integration)")
ax.legend(); pl(ax,"b")

ax=axes[2]
ens=M["climate"]["ensemble"]
ssp245=[ens[s]["SSP2-4.5_2100"] for s in sites]
ssp585=[ens[s]["SSP5-8.5_2100"] for s in sites]
for i,s in enumerate(sites):
    a=ssp245[i]; b=ssp585[i]
    ax.plot([i-0.19]*2,[a["pct_band"][0],a["pct_band"][1]],color=CB["blue"],lw=1.0)
    ax.scatter([i-0.19],[a["pct_best"]],s=26,color=CB["blue"],zorder=5)
    ax.plot([i+0.19]*2,[b["pct_band"][0],b["pct_band"][1]],color=CB["red"],lw=1.0)
    ax.scatter([i+0.19],[b["pct_best"]],s=26,color=CB["red"],zorder=5)
ax.axhline(0,color="k",lw=0.5)
ax.set_xticks(xs); ax.set_xticklabels(short,rotation=45,ha="right",fontsize=6)
ax.set_ylabel("2100 Δ annual potential (%)")
ax.scatter([],[],s=26,color=CB["blue"],label="SSP2-4.5 (dot = best, line = likely band)")
ax.scatter([],[],s=26,color=CB["red"],label="SSP5-8.5")
ax.legend(fontsize=5.4,loc="lower left"); pl(ax,"c")
plt.tight_layout(); plt.savefig("figures/Fig4_climate.png",dpi=300); plt.savefig("figures/Fig4_climate.pdf"); plt.close()

# ===== Fig5: six events x estimators =====
fig,axes=plt.subplots(1,2,figsize=(7.1,2.9))
ax=axes[0]
rh=M["rehearsals"]
names=list(rh.keys())
sh=["Corsica\nSh×Sb","Senegal\nSh×Sc","Niger\nSh×Sb","Cameroon\nSh×Si","Guadeloupe\nSm×Sr","Sb×Sc\nreal mito"]
x=np.arange(6); w=0.2
gb=[rh[k]["P_gb"] for k in names]
ts=[rh[k]["P_gb_tempscaled"] for k in names]
lg=[rh[k]["P_logistic"] for k in names]
nn=[rh[k]["NN_label_prob"] for k in names]
tr=[rh[k]["truth"] for k in names]
ax.bar(x-1.5*w,gb,w,color=CB["blue"],label="GB (raw)")
ax.bar(x-0.5*w,ts,w,color=CB["teal"],label="GB temp-scaled (official)")
ax.bar(x+0.5*w,lg,w,color=CB["yellow"],label="L1 logistic")
ax.bar(x+1.5*w,nn,w,color=CB["grey"],label="nearest neighbour")
ax.scatter(x,tr,marker="*",s=80,color=CB["red"],zorder=6,label="truth")
ax.set_xticks(x); ax.set_xticklabels(sh,fontsize=5.6)
ax.set_ylabel("blind P(human-infecting)"); ax.set_ylim(0,1.15)
ax.legend(fontsize=5.2,loc="upper right",ncol=2); pl(ax,"a")

ax=axes[1]
intro=json.load(open("results/e15_introgression.json"))
ms=sorted(float(k) for k in intro)
ps=[intro[str(round(m,2))]["P_seq"] for m in ms]
ax.plot(ms,ps,"-o",ms=3,color=CB["blue"],lw=1.1)
ax.axvspan(0,0.1,color=CB["orange"],alpha=0.12)
ax.set_xlabel("introgression fraction m (S. haematobium → S. bovis)")
ax.set_ylabel("blind P(human)")
ax.text(0.05,0.9,"decision boundary sits within\n10% of the haematobium end",fontsize=5.6,ha="center")
pl(ax,"b")
plt.tight_layout(); plt.savefig("figures/Fig5_rehearsals.png",dpi=300); plt.savefig("figures/Fig5_rehearsals.pdf"); plt.close()

# ===== ED7: convergence =====
fig,ax=plt.subplots(figsize=(3.6,2.6))
cv=M["convergence"]
ns=sorted(int(k) for k in cv)
mu=[cv[str(n)]["mean_width"] for n in ns]
sd=[cv[str(n)]["sd"] for n in ns]
ax.errorbar(ns,mu,yerr=sd,fmt="-o",ms=4,color=CB["purple"],capsize=2,lw=1.0)
ax.set_xlabel("panel size n (subsampled)"); ax.set_ylabel("ΔR 95% CI width (mean ± sd)")
ax.set_title("host range, base sequence block",fontsize=7)
plt.tight_layout(); plt.savefig("figures/EDFig7_convergence.png",dpi=300); plt.savefig("figures/EDFig7_convergence.pdf"); plt.close()

# ===== ED8: baselines =====
fig,ax=plt.subplots(figsize=(3.9,2.7))
b=M["baselines"]
models=["GB","RF","L2_logistic","kNN5","GaussianNB","B_tax"]
xl=["GB","RF","L2\nlogistic","kNN-5","Gaussian\nNB","B_tax"]
x=np.arange(len(models)); w=0.38
hr=[b["host_range"][m] for m in models]; hu=[b["human"][m] for m in models]
ax.bar(x-w/2,hr,w,color=CB["blue"],label="host range")
ax.bar(x+w/2,hu,w,color=CB["orange"],label="human infection")
ax.set_xticks(x); ax.set_xticklabels(xl,fontsize=6)
ax.set_ylabel("LOSO macro-F1"); ax.set_ylim(0,0.9)
ax.legend(); ax.set_title("estimator suite, same folds",fontsize=7)
plt.tight_layout(); plt.savefig("figures/EDFig8_baselines.png",dpi=300); plt.savefig("figures/EDFig8_baselines.pdf"); plt.close()

# ===== ED9: palaeo weighted =====
fig,ax=plt.subplots(figsize=(3.9,2.7))
from scipy import stats
p=M["paleo"]
xs=np.linspace(0.01,0.99,300)
for key,lab,col in (("unw","unweighted (n=17)",CB["blue"]),("wtd","absence anchors half-weight",CB["purple"]),("pres","presence anchors only (n=10)",CB["orange"])):
    a_,b_=p[key]["alpha"],p[key]["beta"]
    ax.plot(xs,stats.beta(a_,b_).pdf(xs),color=col,lw=1.2,label=lab)
ax.set_xlabel("posterior concordance rate"); ax.set_ylabel("density")
ax.legend(fontsize=5.6); plt.tight_layout()
plt.savefig("figures/EDFig9_paleo_weighted.png",dpi=300); plt.savefig("figures/EDFig9_paleo_weighted.pdf"); plt.close()
print("V4 figures done")
