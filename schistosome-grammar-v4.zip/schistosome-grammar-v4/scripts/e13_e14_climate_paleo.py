#!/usr/bin/env python3
"""E13: quantitative climate-layer projection C(t) — threshold-anchored R0(T) applied to
real ERA5 monthly reanalysis (6 endemic foci, 1990-2025) with CMIP6 delta-method scenarios.
E14: palaeoparasitological anchor posterior (10 curated anchors)."""
import csv, json, math
import numpy as np
from collections import defaultdict

# ---- threshold-anchored R0(T) (V2 anchors; Zhou 2008, Mangal 2008, Tabo 2024) ----
def R0T(T):
    if T < 15.4: return 0.0
    if T < 20: return 0.70 * (T-15.4)/(20-15.4)
    if T <= 27: return 1.0
    if T <= 30: return 1.0 - (1.0-0.40)*(T-27)/3
    if T <= 33: return 0.40 - (0.40-0.03)*(T-30)/3
    if T <= 35: return 0.03 - (0.03-0.006)*(T-33)/2
    return 0.006

rows = list(csv.DictReader(open("data/era5_monthly_sixsites.csv")))
sites = sorted(set(r["site"] for r in rows))
clim = defaultdict(list)   # site -> monthly climatology 1990-2020 baseline
for r in rows:
    y = int(r["month"][:4])
    if 1990 <= y <= 2020:
        clim[r["site"]].append((int(r["month"][5:7]), float(r["tmean_c"])))
# seasonal baseline = mean per calendar month
base = {s: [np.mean([v for m,v in clim[s] if m==mo]) for mo in range(1,13)] for s in sites}

# CMIP6 regional warming deltas (IPCC AR6 WGI Interactive Atlas, land means, vs 1995-2014):
# East Asia & East/West Africa approximations from published CMIP6 ensemble medians (Table 4.1/Atlas chapter)
DT = {  # (scenario, year): (east_china_dt, west_africa_dt, east_africa_dt)
 ("SSP2-4.5", 2050): (1.7, 1.9, 1.7), ("SSP2-4.5", 2070): (2.4, 2.7, 2.4), ("SSP2-4.5", 2100): (2.8, 3.1, 2.8),
 ("SSP5-8.5", 2050): (2.2, 2.5, 2.2), ("SSP5-8.5", 2070): (3.4, 3.9, 3.4), ("SSP5-8.5", 2100): (4.8, 5.4, 4.9),
}
SITE_GROUP = {"Yueyang_Dongting_CN":"cn","Anxiang_Dongting_CN":"cn","Guichi_Anhui_CN":"cn",
              "RichardToll_Senegal":"wa","Mwache_Kenya":"ea","Ukerewe_Tanzania":"ea"}
GIDX = {"cn":0,"wa":1,"ea":2}

def annual_potential(tser):
    return float(np.sum([R0T(t) for t in tser]))  # monthly integral, plateau=1 -> max 12

proj = {}
for s in sites:
    b = base[s]
    # observed decadal trend from ERA5 (real)
    dec = []
    for y0 in range(1990, 2020, 10):
        vals = [float(r["tmean_c"]) for r in rows if r["site"]==s and y0 <= int(r["month"][:4]) < y0+10]
        dec.append(np.mean(vals))
    obs_trend = (dec[-1]-dec[0])/ (len(dec)-1)  # per decade
    out = {"observed_annual_potential_1990s": None, "observed_annual_potential_2020s": None,
           "baseline": round(annual_potential(b),2), "trend_C_per_decade": round(float(obs_trend),3)}
    for y0 in (1990, 2020):
        vals = [float(r["tmean_c"]) for r in rows if r["site"]==s and y0 <= int(r["month"][:4]) < y0+10]
        out[f"observed_annual_potential_{y0}s"] = round(annual_potential(vals),2)
    for (sc, yr), dts in DT.items():
        dt = dts[GIDX[SITE_GROUP[s]]]
        pot = annual_potential([t+dt for t in b])
        out[f"{sc}_{yr}"] = round(pot,2)
        out[f"{sc}_{yr}_pct_change"] = round(100*(pot/out["baseline"]-1),1)
    proj[s] = out
print(json.dumps(proj, indent=1))
json.dump({"R0T_anchors": {"15.4C":0.0,"20C":0.70,"22-27C":1.0,"30C":0.40,"33C":0.03,"35C":0.006},
           "sites": proj, "ERA5_source": "Open-Meteo archive API (ERA5 monthly means, 1990-2025)",
           "CMIP6_deltas": {f"{k[0]}_{k[1]}": v for k,v in DT.items()}},
          open("results/e13_climate_projection.json","w"), indent=1)

# ---- E14 palaeo anchors (10 curated) ----
anchors = [
 {"site":"Gebelein (Predynastic Egypt)","age_bp":5150,"taxon":"Schistosoma sp.","method":"ELISA antigen","obs":"present","pred":"present","verdict":"concordant","ref":"Miller et al. 1992 BMJ 304:555"},
 {"site":"Thebes, 20th Dynasty (Egypt)","age_bp":3100,"taxon":"S. haematobium","method":"egg microscopy","obs":"present","pred":"present","verdict":"concordant","ref":"Ruffer 1910 BMJ 1:16"},
 {"site":"Egyptian mummies (immunodiagnosis)","age_bp":3000,"taxon":"Schistosoma sp.","method":"CAA monoclonal","obs":"present","pred":"present","verdict":"concordant","ref":"Deelder et al. 1990 Lancet 335:724"},
 {"site":"Mawangdui tomb, Changsha (China)","age_bp":2168,"taxon":"S. japonicum","method":"egg microscopy","obs":"present","pred":"present","verdict":"concordant","ref":"Yeh & Mitchell 2016; Shin et al. 2018"},
 {"site":"Fenghuangshan tomb, Jiangling (China)","age_bp":2167,"taxon":"S. japonicum","method":"egg microscopy","obs":"present","pred":"present","verdict":"concordant","ref":"Yeh & Mitchell 2016; Shin et al. 2018"},
 {"site":"Sai Island, Meroitic Nubia (Sudan)","age_bp":2000,"taxon":"Schistosoma sp.","method":"eggs/immunology","obs":"present","pred":"present","verdict":"concordant","ref":"Harter 2003; Geus 1995"},
 {"site":"Neolithic-Alpine lake settlements (Europe)","age_bp":5000,"taxon":"Schistosoma-genus","method":"sediment eggs","obs":"present","pred":"absent","verdict":"partial","ref":"Le Bailly & Bouchet; Shin et al. 2018"},
 {"site":"Montbeliard latrine (15th c. France)","age_bp":500,"taxon":"S. mansoni","method":"latrine eggs","obs":"present","pred":"absent","verdict":"discordant","ref":"Bouchet et al. 2002 J Parasitol 88:404; Bouchet & Paicheler 1995"},
 {"site":"Jerusalem Mamluk cesspool (15th c.)","age_bp":500,"taxon":"Schistosoma sp.","method":"cesspool eggs","obs":"present","pred":"absent","verdict":"partial","ref":"Yeh et al. 2015 IJPP 9"},
 {"site":"Joseon dynasty mummies (Korea)","age_bp":400,"taxon":"Schistosoma sp.","method":"systematic survey","obs":"absent","pred":"absent","verdict":"concordant","ref":"Seo et al. 2014 Korean J Parasitol 52:235"},
]
succ = sum(1.0 if a["verdict"]=="concordant" else 0.5 if a["verdict"]=="partial" else 0.0 for a in anchors)
n = len(anchors)
from scipy import stats
a_, b_ = succ + 1, (n - succ) + 1
post = stats.beta(a_, b_)
mean = post.mean(); lo, hi = post.ppf(0.025), post.ppf(0.975)
out = {"n_anchors": n, "concordant": sum(1 for a in anchors if a["verdict"]=="concordant"),
       "partial": sum(1 for a in anchors if a["verdict"]=="partial"),
       "discordant": sum(1 for a in anchors if a["verdict"]=="discordant"),
       "beta_posterior": {"alpha": a_, "beta": b_, "mean": round(float(mean),2),
                          "cri95": [round(float(lo),2), round(float(hi),2)]},
       "anchors": anchors}
print(json.dumps(out["beta_posterior"]), out["n_anchors"], "anchors")
json.dump(out, open("results/e14_paleo.json","w"), indent=1)

# ---- resistance boundary table (P3/P8) ----
resb = {}
for u in (0.396, 0.617, 0.75, 0.85):
    for b in (1.0, 1.4, 3.0):
        resb[f"u{u}_b{b}"] = {"s_star": round(b*u/(1-u),3)}
json.dump({"boundary": resb, "who2024_global": 0.396, "who2024_sac": 0.617},
          open("results/e12_boundary.json","w"), indent=1)
