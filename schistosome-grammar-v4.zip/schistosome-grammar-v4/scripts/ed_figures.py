#!/usr/bin/env python3
"""Extended Data figures 1-6."""
import json, csv, itertools, math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":7.5,"axes.titlesize":8,
 "axes.linewidth":0.6,"pdf.fonttype":42,"legend.fontsize":6.5,"legend.frameon":False})
CB = {"blue":"#3B6FB6","orange":"#E8853D","green":"#4F9C6B","red":"#C4453C",
      "purple":"#7E57A5","teal":"#2B9C93","grey":"#8C8C8C","yellow":"#C9A83A"}
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]
adj = json.load(open("results/e10_adjudication.json"))
rehe = json.load(open("results/e15_rehearsals.json"))
markov = json.load(open("results/e10_markov.json"))
powr = json.load(open("results/e16_power.json"))

def panel_label(ax, s, dx=-0.14):
    ax.text(dx, 1.05, s, transform=ax.transAxes, fontsize=9, fontweight="bold", va="top")

# ---- ED1 estimator sensitivity ----
fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.4))
blocks = ["z_seq","z_seq_base","z_eco","combined"]
for j,(tg,lab) in enumerate((("host_range","Host range"),("human","Human infection"))):
    ax = axes[j]; x=np.arange(4); w=0.38
    gb=[adj[f"n22|{tg}|{b}|gb"]["f1"] for b in blocks]
    lg=[adj[f"n22|{tg}|{b}|log"]["f1"] for b in blocks]
    ax.bar(x-w/2, gb, w, color=CB["blue"], label="gradient boosting")
    ax.bar(x+w/2, lg, w, color=CB["yellow"], label="L1 logistic")
    ax.axhline(adj[f"n22|{tg}|B_tax"]["f1"], color=CB["red"], ls="--", lw=0.8, label="B_tax")
    ax.set_xticks(x); ax.set_xticklabels(blocks, fontsize=6)
    ax.set_ylabel("LOSO macro-F1"); ax.set_title(lab); ax.set_ylim(0,0.66)
    if j==0: ax.legend(loc="upper right", fontsize=5.6)
    panel_label(ax, "ab"[j])
plt.tight_layout(); plt.savefig("figures/EDFig1_estimators.png", dpi=300)
plt.savefig("figures/EDFig1_estimators.pdf"); plt.close()

# ---- ED2 Markov scatter ----
def behav_dist(t1, t2):
    r1, r2 = PANEL[t1], PANEL[t2]
    import math as m
    hcs=[m.log10(int(PANEL[x]["def_host_count"])) for x in TAXES]
    h=(abs(m.log10(int(r1["def_host_count"]))-m.log10(int(r2["def_host_count"]))))/ (max(hcs)-min(hcs))
    hum=abs(int(r1["human_infecting"])-int(r2["human_infecting"]))
    z=abs(float(r1["zoonotic"])-float(r2["zoonotic"]))
    return m.sqrt(h*h+hum*hum+z*z)
fig, ax = plt.subplots(figsize=(3.6, 3.0))
pairs=list(itertools.combinations(TAXES,2))
sd=[dist["D"][f"{a}|{b}"] for a,b in pairs]; bd=[behav_dist(a,b) for a,b in pairs]
same=[PANEL[a]["clade"]==PANEL[b]["clade"] for a,b in pairs]
xs=np.array(sd); ys=np.array(bd)
ax.scatter(xs[np.array(same)], ys[np.array(same)], s=6, color=CB["orange"], alpha=0.6, label="same clade")
ax.scatter(xs[~np.array(same)], ys[~np.array(same)], s=6, color=CB["blue"], alpha=0.45, label="different clades")
from scipy import stats
rho, p = stats.spearmanr(sd, bd)
ax.text(0.03, 0.95, f"$\\rho$ = {rho:.3f}\npermutation P = {markov['perm_p']:.3f}\nn pairs = {len(pairs)}",
        transform=ax.transAxes, va="top", fontsize=6.5)
ax.set_xlabel("structural distance (standardized mt 4-mer)")
ax.set_ylabel("behavioural distance"); ax.legend(loc="upper right", fontsize=5.6)
panel_label(ax, "")
plt.tight_layout(); plt.savefig("figures/EDFig2_markov.png", dpi=300); plt.savefig("figures/EDFig2_markov.pdf"); plt.close()

# ---- ED3 de novo without abstention ----
fig, ax = plt.subplots(figsize=(3.9, 2.6))
events=["Corsica_2013 (Sh x Sb)","Senegal_zone (Sh x Sc)","Real hybrid mito (Sb x Sc, PV535797)"]
enames=["Corsica\nSh×Sb","Senegal\nSh×Sc","Real Sb×Sc\nmito"]
seq=[rehe[f"{e}|de novo"]["P_human_seq"] for e in events]
comb=[rehe[f"{e}|de novo"]["P_human_combined"] for e in events]
truth=[rehe[f"{e}|in-clade"]["truth"] for e in events]
x=np.arange(3)
ax.bar(x-0.19, seq, 0.38, color=CB["blue"], label="sequence layer")
ax.bar(x+0.19, comb, 0.38, color=CB["teal"], label="seq + ecology")
ax.scatter(x, truth, marker="*", s=90, color=CB["red"], zorder=5, label="ground truth")
ax.set_xticks(x); ax.set_xticklabels(enames, fontsize=6.2)
ax.set_ylabel("raw de novo P(human)")
ax.set_title("de novo mode without abstention —\nthe abstention rule, not the raw score, is the deliverable", fontsize=6.6)
ax.legend(loc="upper right", fontsize=5.6); panel_label(ax, "")
plt.tight_layout(); plt.savefig("figures/EDFig3_denovo.png", dpi=300); plt.savefig("figures/EDFig3_denovo.pdf"); plt.close()

# ---- ED4 distance matrix ----
fig, ax = plt.subplots(figsize=(3.9, 3.2))
D = np.zeros((len(TAXES), len(TAXES)))
for a,b in itertools.combinations(TAXES,2):
    D[TAXES.index(a),TAXES.index(b)] = D[TAXES.index(b),TAXES.index(a)] = dist["D"][f"{a}|{b}"]
im = ax.imshow(D, cmap="viridis")
short=[t.replace("Schistosoma ","S. ").replace("Hybrid_S.bovis_x_S.curassoni","S.b×S.c hybrid").replace("Trichobilharzia ","T. ") for t in TAXES]
ax.set_xticks(range(len(TAXES))); ax.set_xticklabels(short, rotation=90, fontsize=4.6)
ax.set_yticks(range(len(TAXES))); ax.set_yticklabels(short, fontsize=4.6)
plt.colorbar(im, ax=ax, fraction=0.046, label="4-mer Manhattan distance")
panel_label(ax, "")
plt.tight_layout(); plt.savefig("figures/EDFig4_distmatrix.png", dpi=300); plt.savefig("figures/EDFig4_distmatrix.pdf"); plt.close()

# ---- ED5 power ----
fig, ax = plt.subplots(figsize=(3.6, 2.6))
keys=["host_range|n14","host_range|n22","human|n14","human|n22"]
vals=[powr[k]["ci_excl_zero_rate"] for k in keys]
ax.bar(range(4), vals, color=[CB["grey"],CB["blue"],CB["grey"],CB["orange"]], width=0.55)
for i,v in enumerate(vals): ax.text(i, v+0.02, f"{v:.2f}", ha="center", fontsize=6.5)
ax.set_xticks(range(4)); ax.set_xticklabels(["host range\nn=14","host range\nn=22","human\nn=14","human\nn=22"], fontsize=6)
ax.set_ylabel("rate of ΔR CI excluding zero"); ax.set_ylim(0,1.1)
ax.set_title("resampling-based CI behaviour (300 replicates)", fontsize=7)
panel_label(ax, "")
plt.tight_layout(); plt.savefig("figures/EDFig5_power.png", dpi=300); plt.savefig("figures/EDFig5_power.pdf"); plt.close()
print("ED1-5 done")
