#!/usr/bin/env python3
"""ED5: label-noise stress test at n=22 (z_seq_base, gb)."""
import csv, json
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import f1_score

rng = np.random.default_rng(11)
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]
supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]
BASE_KEYS = ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")
def base_vector(t):
    seq = "".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()
    n=len(seq); a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    at=(a-tt)/(a+tt); gcs=(g-c)/(g+c); gc_=(g+c)/n
    obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([gc_, at, gcs] + [odds[k] for k in BASE_KEYS])
F = {t: base_vector(t) for t in supervised}
y0 = {t: PANEL[t]["host_range_class"] for t in supervised}
out = {}
for lvl in (0.0, 0.1, 0.2, 0.3):
    f1s = []
    for rep in range(30):
        y = {}
        for t in supervised:
            y[t] = y0[t] if rng.random() >= lvl else rng.choice([c for c in ("narrow","medium","broad") if c != y0[t]])
        sc = []
        for held in supervised:
            tr=[t for t in supervised if t!=held]
            m = GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
            m.fit(np.array([F[t] for t in tr]), [y[t] for t in tr])
            sc.append((y[held], m.predict(np.array([F[held]]))[0]))
        f1s.append(f1_score([s[0] for s in sc],[s[1] for s in sc], average="macro"))
    f1s=np.array(f1s)
    out[str(lvl)] = {"mean": round(float(f1s.mean()),3), "ci": [round(float(np.quantile(f1s,0.025)),3), round(float(np.quantile(f1s,0.975)),3)]}
    print(lvl, out[str(lvl)], flush=True)
json.dump(out, open("results/ed5_noise_n22.json","w"), indent=1)
