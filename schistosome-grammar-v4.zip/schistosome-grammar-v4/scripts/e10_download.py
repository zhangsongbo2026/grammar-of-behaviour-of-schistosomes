#!/usr/bin/env python3
"""Download real mitochondrial sequences for the expanded schistosome panel."""
import json, time, urllib.request, os
os.makedirs("data/fasta", exist_ok=True)

# Tier 1: complete/organelle mitochondrial genomes
TIER1 = {
 "Schistosoma_mansoni":      "NC_002545.1",
 "Schistosoma_rodhaini":     "OX104043.1",
 "Schistosoma_haematobium":  "NC_008074.1",
 "Schistosoma_bovis":        "CM014335.1",
 "Schistosoma_curassoni":    "AP017708.1",
 "Schistosoma_guineensis":   "MK341584.1",
 "Schistosoma_intercalatum": "OX103731.1",
 "Schistosoma_mattheei":     "AP017710.1",
 "Schistosoma_margrebowiei": "AP017709.1",
 "Schistosoma_japonicum":    "NC_002544.1",
 "Schistosoma_mekongi":      "NC_002529.1",
 "Schistosoma_spindale":     "OX336422.1",
 "Schistosoma_indicum":      "NC_047240.1",
 "Schistosoma_turkestanicum":"OX103978.1",
 "Trichobilharzia_regenti":  "NC_009680.1",
 "Trichobilharzia_szidati":  "NC_036411.1",
 "Hybrid_S.bovis_x_S.curassoni":"PV535797.1",
}
# Tier 2: concatenated mt fragments (partial coverage)
TIER2 = {
 "Schistosoma_nasale":       ["KR607232.1","KR423844.1","KR607262.1","AY157205.1"],
 "Schistosoma_incognitum":   ["AB771922.1","HM594943.1","AY157199.1"],
 "Schistosoma_sinensium":    ["AY157197.1","AY090787.1"],
 "Schistosoma_edwardiense":  ["AY197347.1"],
 "Schistosoma_hippopotami":  ["AY197346.1"],
 "Schistosoma_leiperi":      ["AY157207.1"],
}
def fetch_fasta(acc):
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?" + \
        urllib.parse.urlencode({"db":"nuccore","id":acc,"rettype":"fasta","retmode":"text"})
    for a in range(4):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                return r.read().decode()
        except Exception as e:
            time.sleep(4)
    return None
import urllib.parse
log = []
for name, acc in list(TIER1.items()) + list(TIER2.items()):
    accs = acc if isinstance(acc, list) else [acc]
    text = ""
    for a in accs:
        fa = fetch_fasta(a)
        if fa and fa.startswith(">"):
            text += fa
            log.append((name, a, len(fa.split(chr(10)))-1))
        else:
            log.append((name, a, "FAIL"))
        time.sleep(0.6)
    if text:
        with open(f"data/fasta/{name}.fasta","w") as f: f.write(text)
print("\n".join(str(x) for x in log))
