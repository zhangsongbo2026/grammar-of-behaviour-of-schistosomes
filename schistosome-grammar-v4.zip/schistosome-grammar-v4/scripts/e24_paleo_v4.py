#!/usr/bin/env python3
"""P2-10: palaeo anchor expansion 10 -> 17 with presence/absence weighting and
import-case migration sensitivity."""
import json
from scipy import stats
import numpy as np

OLD = json.load(open("results/e14_paleo.json"))["anchors"]
NEW = [
 {"site":"Crusader-period Saranda Kolones latrines, Paphos (Cyprus)","age_bp":800,"taxon":"Schistosoma sp.","method":"cesspool microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Anastasiou & Mitchell 2013"},
 {"site":"Medieval-Renaissance Brussels latrines (Belgium)","age_bp":500,"taxon":"Schistosoma sp.","method":"latrine microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Graff et al. 2020 Parasitology 147"},
 {"site":"Islamic medieval Cordoba and Mertola (Iberia)","age_bp":900,"taxon":"Schistosoma sp.","method":"latrine microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Knorr et al. 2019 Int J Paleopathol 26"},
 {"site":"Roman Baths latrine, Sagalassos (Turkey)","age_bp":1750,"taxon":"Schistosoma sp.","method":"latrine microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Williams et al. 2017 Int J Paleopathol 19"},
 {"site":"Neolithic-to-Roman Kea (Greece)","age_bp":2500,"taxon":"Schistosoma sp.","method":"coprolite/sediment","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Anastasiou et al. 2018 J Archaeol Sci Rep"},
 {"site":"Hellenistic Delos (Greece)","age_bp":2200,"taxon":"Schistosoma sp.","method":"sediment microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Roche et al. 2025 Archaeol Anthropol Sci 17"},
 {"site":"Eastern Roman Empire latrine corpus","age_bp":1700,"taxon":"Schistosoma sp.","method":"latrine microscopy","obs":"absent","pred":"absent","verdict":"concordant","weight":"absence","ref":"Ledger et al. 2020 Am J Archaeol 124"},
]
anchors = OLD + NEW
for a in anchors:
    a.setdefault("weight","presence")
n=len(anchors)
def posterior(items):
    succ=sum((1.0 if a["verdict"]=="concordant" else 0.5 if a["verdict"]=="partial" else 0.0)*
             (1.0 if a["weight"]=="presence" else 0.5) for a in items)
    wsum=sum(1.0 if a["weight"]=="presence" else 0.5 for a in items)
    a_,b_=succ+1,(wsum-succ)+1
    post=stats.beta(a_,b_)
    return {"alpha":round(a_,1),"beta":round(b_,1),"mean":round(post.mean(),2),
            "cri95":[round(post.ppf(0.025),2),round(post.ppf(0.975),2)],"effective_n":round(wsum,1)}
unw=posterior([{**a,"weight":"presence"} for a in anchors])
wtd=posterior(anchors)
pres_only=posterior([a for a in anchors if a["weight"]=="presence"])

# import-case migration sensitivity: P(observing an imported S. mansoni egg at a non-endemic
# European site within T years) as a function of annual travel intensity lambda
# simple Poisson exposure model: eggs recoverable if at least one infected traveller contributes
lam=np.linspace(0,0.05,50)  # infected-traveller deposition rate per site-year (arb. units)
T=100
p_detect=1-np.exp(-lam*T)
sens={"model":"Poisson exposure: P(>=1 imported deposition in T years) = 1-exp(-lambda*T)",
      "T_years":T,"lambda":lam.tolist(),"p_detect":p_detect.tolist(),
      "note":"calibrates what travel intensity is needed for the Montbeliard record to be expected rather than anomalous; lambda ~ 0.03/site-year suffices for P>95% over a century"}

out={"n_anchors":n,"anchors":anchors,
 "posterior_unweighted":unw,"posterior_weighted":wtd,"posterior_presence_only":pres_only,
 "import_sensitivity":sens,
 "concordant":sum(1 for a in anchors if a["verdict"]=="concordant"),
 "partial":sum(1 for a in anchors if a["verdict"]=="partial"),
 "discordant":sum(1 for a in anchors if a["verdict"]=="discordant")}
print("n=",n,"unw:",unw,"weighted:",wtd,"presence-only:",pres_only)
json.dump(out,open("results/e24_paleo_v4.json","w"),indent=1)
