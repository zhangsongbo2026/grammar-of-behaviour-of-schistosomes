#!/usr/bin/env python3
"""E13: climate layer C(t) — real ERA5 monthly reanalysis (Open-Meteo archive API)
for six endemic foci, 1990-2025."""
import json, time, urllib.request, urllib.parse, csv

SITES = {
 "Yueyang_Dongting_CN": (29.37, 113.13, "China", "Dongting Lake (Hunan)"),
 "Anxiang_Dongting_CN": (29.41, 112.16, "China", "Dongting Lake (Hunan)"),
 "Guichi_Anhui_CN":     (30.66, 117.49, "China", "Yangtze marshland (Anhui)"),
 "RichardToll_Senegal": (16.47, -15.70, "Senegal", "Senegal River Basin"),
 "Mwache_Kenya":        (-4.06, 39.66, "Kenya", "Coastal Kenya"),
 "Ukerewe_Tanzania":    (-2.10, 33.03, "Tanzania", "Lake Victoria"),
}
rows_all = []
for name, (lat, lon, country, region) in SITES.items():
    url = "https://archive-api.open-meteo.com/v1/archive?" + urllib.parse.urlencode({
        "latitude": lat, "longitude": lon,
        "start_date": "1990-01-01", "end_date": "2025-07-31",
        "monthly": "temperature_2m_mean", "timezone": "auto"})
    d = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(url, timeout=90) as r:
                d = json.loads(r.read()); break
        except Exception as e:
            print(name, "retry", attempt, type(e).__name__, flush=True); time.sleep(5)
    if not d: continue
    mon = d.get("monthly", {})
    for t, temp in zip(mon.get("time", []), mon.get("temperature_2m_mean", [])):
        rows_all.append({"site": name, "country": country, "region": region,
                         "lat": lat, "lon": lon, "month": t, "tmean_c": temp})
    print(name, len(mon.get("time", [])), "months", mon.get("time",["?"])[0], "->",
          mon.get("time",["?"])[-1], flush=True)
    time.sleep(1.5)
with open("data/era5_monthly_sixsites.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_all[0].keys()))
    w.writeheader(); w.writerows(rows_all)
print("total rows:", len(rows_all))
