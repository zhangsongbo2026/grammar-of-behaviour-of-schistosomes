#!/usr/bin/env python3
"""P0-3/P0-4: primary estimator (temperature-scaled GB, nested in LOSO), ECE before/after,
nearest-neighbour baseline, and SIX literature-documented hybrid rehearsals."""
import csv, json, itertools
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score

rng = np.random.default_rng(7)
PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist = json.load(open("results/e10_dist.json"))
TAXES = dist["taxes"]; k4s = np.array(dist["k4s"])
BASE_KEYS = ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")
supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]

def read_seq(t):
    return "".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()

def base_vec_seq(seq):
    n=len(seq); a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    at=(a-tt)/(a+tt); gcs=(g-c)/(g+c); gc_=(g+c)/n
    obs=Counter(seq[i:i+2] for i in range(n-1)); mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k: obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([gc_, at, gcs] + [odds[k] for k in BASE_KEYS])

def k4vec(seq):
    n=len(seq); k4=Counter(seq[i:i+4] for i in range(n-3))
    v=np.zeros(256)
    for i,k in enumerate(["".join(p) for p in itertools.product("ACGT",repeat=4)]):
        v[i]=k4.get(k,0)
    return v/(n-3)

def base_vec_tax(t):
    f = base_vec_seq(read_seq(t))
    f[0] = dist["gc"][t]
    return f

t1idx=[i for i,t in enumerate(TAXES) if PANEL[t]["tier"]=="tier1"]
X1=k4s[t1idx]; mean=X1.mean(0); std=X1.std(0)+1e-12
U,S,Vt=np.linalg.svd(X1-mean, full_matrices=False); comp=Vt[:5]
med=np.median((X1-mean)@comp.T, axis=0)
def pca5_seq(seq): return ((k4vec(seq)-mean)/std) @ comp.T
def pca5_tax(t):
    if PANEL[t]["tier"]=="tier1": return (k4s[TAXES.index(t)]-mean)@comp.T
    return med

def feats_full_x(x):
    if isinstance(x,str) and x in TAXES:
        return np.concatenate([base_vec_tax(x), pca5_tax(x)])
    return np.concatenate([base_vec_seq(x), pca5_seq(x)])

def feats_eco(r):
    gens=["Biomphalaria","Bulinus","Oncomelania","Neotricula","Indoplanorbis","Radix","Tricula","unknown"]
    zones=["tropical","subtropical","temperate"]
    return np.array([1.0 if r["snail_genus"]==g else 0.0 for g in gens]+
                    [1.0 if r["climate_zone"]==z else 0.0 for z in zones])

def ece(y, p, bins=4):
    y=np.array(y); p=np.array(p); e=0.0; N=len(y)
    per=[]
    for b in range(bins):
        lo,hi=b/bins,(b+1)/bins
        m=(p>=lo)&(p<hi) if b<bins-1 else (p>=lo)&(p<=hi)
        if m.sum()==0: continue
        e += m.sum()/N*abs(y[m].mean()-p[m].mean())
        per.append({"bin":[round(lo,2),round(hi,2)],"n":int(m.sum()),
                    "mean_p":round(float(p[m].mean()),3),"obs":round(float(y[m].mean()),3)})
    return e, per

def temp_scale(scores, y, T_grid=np.linspace(0.5,4,15)):
    # scale on raw margins proxy: use probability logits
    logits=np.log(np.clip(scores,1e-6,1-1e-6)/(1-np.clip(scores,1e-6,1-1e-6)))
    best=None
    for T in T_grid:
        s=1/(1+np.exp(-logits/T))
        e,_=ece(y,s)
        if best is None or e<best[1]: best=(T,e,s)
    return best

# ---- LOSO with temperature-scaled GB (primary) ----
yv={t:int(PANEL[t]["human_infecting"]) for t in supervised}
pred_raw, pred_ts, ys = [], [], []
for held in supervised:
    tr=[t for t in supervised if t!=held]
    m=GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
    m.fit(np.array([feats_full_x(t) for t in tr]),[yv[t] for t in tr])
    p=m.predict_proba(np.array([feats_full_x(held)]))[0][1]
    pred_raw.append(p); ys.append(yv[held])
pred_raw=np.array(pred_raw); ys_a=np.array(ys)
# nested temperature scaling: choose T on inner LOSO (leave-one-out within training)
T_inner=[]
for held in supervised:
    tr=[t for t in supervised if t!=held]
    pi, yi =[],[]
    for h2 in tr:
        tr2=[t for t in tr if t!=h2]
        m=GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
        m.fit(np.array([feats_full_x(t) for t in tr2]),[yv[t] for t in tr2])
        pi.append(m.predict_proba(np.array([feats_full_x(h2)]))[0][1]); yi.append(yv[h2])
    T,_,_=temp_scale(np.array(pi), np.array(yi))
    T_inner.append(T)
    s=1/(1+np.exp(-np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6)))/T))
    pred_ts.append(s)
pred_ts=np.array(pred_ts)
e_raw,per_raw = ece(ys,pred_raw); e_ts,per_ts = ece(ys,pred_ts)
f1_raw = f1_score(ys,(pred_raw>=0.5).astype(int)); f1_ts = f1_score(ys,(pred_ts>=0.5).astype(int))
out={"primary_estimator":"temperature-scaled gradient boosting (T chosen by nested leave-one-out, mean T = %.2f)"%np.mean(T_inner),
     "ECE_raw":round(e_raw,3),"ECE_tempscaled":round(e_ts,3),
     "accuracy_raw":round(float(f1_raw),3),"accuracy_ts":round(float(f1_ts),3),
     "reliability_raw":per_raw,"reliability_tempscaled":per_ts}
print(json.dumps({k:v for k,v in out.items() if not k.startswith("reliability")}, indent=1))

# ---- SIX rehearsals ----
EVENTS = {
 "Corsica_2013 (Sh x Sb)": {"parents":["Schistosoma haematobium","Schistosoma bovis"],
   "eco":{"snail_genus":"Bulinus","climate_zone":"temperate"},"truth":1,
   "ref":"Boissier 2016 Lancet ID; Kincaid-Smith 2021"},
 "Senegal_zone (Sh x Sc)": {"parents":["Schistosoma haematobium","Schistosoma curassoni"],
   "eco":{"snail_genus":"Bulinus","climate_zone":"tropical"},"truth":1,
   "ref":"Webster 2013 PLoS NTD; Huyse 2009"},
 "Niger_InnerDelta (Sh x Sb)": {"parents":["Schistosoma haematobium","Schistosoma bovis"],
   "eco":{"snail_genus":"Bulinus","climate_zone":"tropical"},"truth":0,
   "ref":"livestock hybrid zone, human transmission not established (Webster 2013; Boon 2019 context)"},
 "Cameroon_LowerGuinea (Sh x Si)": {"parents":["Schistosoma haematobium","Schistosoma intercalatum"],
   "eco":{"snail_genus":"Bulinus","climate_zone":"tropical"},"truth":1,
   "ref":"Lower Guinea hybridization, human urogenital/intestinal overlap (Leger & Webster 2017)"},
 "Guadeloupe (Sm x Sr)": {"parents":["Schistosoma mansoni","Schistosoma rodhaini"],
   "eco":{"snail_genus":"Biomphalaria","climate_zone":"tropical"},"truth":1,
   "ref":"natural mansoni-rodhaini hybrid, human cases (Theron & Combes; Leger & Webster 2017)"},
 "Real hybrid mito (Sb x Sc, PV535797)": {"seq": read_seq("Hybrid_S.bovis_x_S.curassoni"),
   "eco":{"snail_genus":"Bulinus","climate_zone":"tropical"},"truth":0,
   "ref":"NCBI PV535797 (livestock hybrid)"},
}
res={}
for name,ev in EVENTS.items():
    p1,p2 = ev.get("parents",[None,None])
    eco = feats_eco(ev["eco"])
    if "seq" in ev:
        f = feats_full_x(ev["seq"])
    else:
        s1,s2 = read_seq(p1), read_seq(p2)
        f = (feats_full_x(s1)+feats_full_x(s2))/2.0
    # in-clade: withhold parents
    taxes=[t for t in supervised if t not in (p1,p2) if p1] or supervised
    if p1: taxes=[t for t in supervised if t not in (p1,p2)]
    else: taxes=[t for t in supervised if t not in ("Schistosoma bovis","Schistosoma curassoni")]
    m=GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42)
    m.fit(np.array([feats_full_x(t) for t in taxes]),[yv[t] for t in taxes])
    p_gb=float(m.predict_proba(np.array([f]))[0][1])
    # temperature scale with inner loop
    T,_,_=temp_scale(np.array([float(m.predict_proba(np.array([feats_full_x(t)]))[0][1]) for t in taxes]),
                     np.array([yv[t] for t in taxes]))
    p_ts=float(1/(1+np.exp(-np.log(np.clip(p_gb,1e-6,1-1e-6))/(1-np.clip(p_gb,1e-6,1-1e-6)))/T))
    # logistic
    ml=LogisticRegression(C=1.0,solver="liblinear",random_state=42,max_iter=5000)
    ml.fit(np.array([feats_full_x(t) for t in taxes]),[yv[t] for t in taxes])
    p_lg=float(ml.predict_proba(np.array([f]))[0][1])
    # nearest neighbour in standardized full-feature space
    Z=np.array([feats_full_x(t) for t in taxes]); mu=Z.mean(0); sd=Z.std(0)+1e-12
    zz=(Z-mu)/sd; zf=(f-mu)/sd
    d=np.linalg.norm(zz-zf,axis=1); j=int(np.argmin(d))
    nn_tax=taxes[j]
    p_nn=float(yv[nn_tax])
    res[name]={"P_gb":round(p_gb,2),"P_gb_tempscaled":round(p_ts,2),"P_logistic":round(p_lg,2),
      "NN_taxon":nn_tax,"NN_label_prob":p_nn,"NN_distance":round(float(d[j]),2),
      "truth":ev["truth"],"ref":ev["ref"]}
    print(name, res[name], flush=True)
out["rehearsals"]=res
json.dump(out, open("results/e21_estimators_nn.json","w"), indent=1)
print("saved")
