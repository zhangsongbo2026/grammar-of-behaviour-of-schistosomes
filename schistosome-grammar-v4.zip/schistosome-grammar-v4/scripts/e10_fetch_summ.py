import json, urllib.request, urllib.parse, time
ids = json.load(open("data/mt_search_ids.json"))
rows = []
for i in range(0, len(ids), 100):
    chunk = ids[i:i+100]
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?" + urllib.parse.urlencode({
        "db": "nuccore", "id": ",".join(chunk), "retmode": "json"})
    with urllib.request.urlopen(url, timeout=60) as r:
        d = json.loads(r.read())
    for gid in chunk:
        s = d.get("result", {}).get(gid)
        if not s: continue
        rows.append({
            "uid": gid, "accession": s.get("accessionversion"),
            "organism": s.get("organism") or (s.get("subtitle","") if isinstance(s.get("subtitle"),str) else ""),
            "length": s.get("slen"), "title": s.get("title", "")[:150],
            "completeness": s.get("completeness"), "updated": s.get("updatedate","")})
    time.sleep(0.4)
json.dump(rows, open("data/mt_summaries.json","w"), indent=1)
print(len(rows), "summaries")
# unique organisms
from collections import Counter
c = Counter(r["organism"] for r in rows)
for org, n in sorted(c.items()):
    print(n, org)
