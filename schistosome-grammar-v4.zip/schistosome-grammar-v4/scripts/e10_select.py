import json, urllib.request, urllib.parse, time
cand = json.load(open("data/mt_candidates.json"))
ids2 = json.load(open("data/mt_search_ids2.json"))
uid_set = set()
for k, v in cand.items(): uid_set.update(v)
for k, v in ids2.items(): uid_set.update(v)
uid_list = sorted(uid_set)
print("union candidates:", len(uid_list))

rows = []
for i in range(0, len(uid_list), 120):
    chunk = uid_list[i:i+120]
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?" + urllib.parse.urlencode({
        "db": "nuccore", "id": ",".join(chunk), "retmode": "json"})
    for a in range(3):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                d = json.loads(r.read())
            for gid in chunk:
                s = d.get("result", {}).get(gid)
                if not s or s.get("uid") == "uid": continue
                rows.append({"uid": gid, "acc": s.get("accessionversion"),
                    "org": s.get("organism",""), "len": s.get("slen",0),
                    "title": s.get("title","")[:180], "comp": s.get("completeness","")})
            break
        except Exception as e:
            print("retry", i, type(e).__name__); time.sleep(4)
    time.sleep(0.4)
json.dump(rows, open("data/mt_all_summaries.json","w"))
print("rows:", len(rows))

ORG = {"Schistosoma mansoni","Schistosoma rodhaini","Schistosoma haematobium","Schistosoma bovis",
 "Schistosoma curassoni","Schistosoma guineensis","Schistosoma intercalatum","Schistosoma mattheei",
 "Schistosoma margrebowiei","Schistosoma japonicum","Schistosoma mekongi","Schistosoma malayensis",
 "Schistosoma spindale","Schistosoma indicum","Schistosoma nasale","Schistosoma incognitum",
 "Schistosoma turkestanicum","Orientobilharzia turkestanicum","Schistosoma sinensium","Schistosoma edwardiense",
 "Schistosoma hippopotami","Schistosoma leiperi","Schistosoma kisumuensis","Schistosoma ovuncatum",
 "Schistosoma congolensis","Trichobilharzia regenti","Trichobilharzia szidati","Trichobilharzia physella",
 "Heterobilharzia americana","Gigantobilharzia acotylea","Gigantobilharzia huronensis","Ornithobilharzia canaliculata",
 "Dendritobilharzia pulverulenta"}
sel = {}
for r in rows:
    o = r["org"]
    if o not in ORG: continue
    if r["len"] < 13000: continue
    if "complete genome" not in r["title"].lower() and r["comp"] != "Complete": continue
    cur = sel.get(o)
    if cur is None or (r["acc"] or "").startswith("NC_") and not (cur["acc"] or "").startswith("NC_"):
        sel[o] = r
    elif cur is not None and r["len"] > cur["len"] and (r["acc"] or "").startswith("NC_") == (cur["acc"] or "").startswith("NC_"):
        sel[o] = r
print("\nSelected per organism (%d):" % len(sel))
for o in sorted(sel):
    r = sel[o]; print(f"  {o}: {r['acc']} {r['len']}bp  comp={r['comp']}")
json.dump(sel, open("data/mt_selected.json","w"), indent=1)
