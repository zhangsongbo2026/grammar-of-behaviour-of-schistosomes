#!/usr/bin/env python3
"""Fig 1: framework schematic (drawn, not photographic)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":7.5,"pdf.fonttype":42})
CB = {"blue":"#3B6FB6","orange":"#E8853D","green":"#4F9C6B","red":"#C4453C",
      "purple":"#7E57A5","teal":"#2B9C93","grey":"#8C8C8C","yellow":"#C9A83A"}
fig, ax = plt.subplots(figsize=(7.1, 4.6)); ax.axis("off")

def box(x,y,w,h,fc,txt,fs=6.6,ec="none",tc="white",lw=1.0):
    ax.add_patch(FancyBboxPatch((x,y),w,h, boxstyle="round,pad=0.012",
                 fc=fc, ec=ec, lw=lw, mutation_aspect=1))
    ax.text(x+w/2, y+h/2, txt, ha="center", va="center", fontsize=fs, color=tc, wrap=True)

def arrow(x1,y1,x2,y2,c="#555555"):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2), arrowstyle="-|>", mutation_scale=9,
                 lw=0.9, color=c))

# --- a: data foundations ---
box(0.01, 0.655, 0.46, 0.305, "#F4F1EA", "", 1, ec="#BBBBBB")
ax.text(0.012, 0.985, "a  Data foundations (all real, provenance-recorded)", fontsize=7.5, fontweight="bold")
box(0.022, 0.835, 0.20, 0.078, CB["blue"], "23 complete/partial\nmt genomes (ENA/NCBI)", 5.4)
box(0.246, 0.835, 0.20, 0.078, CB["blue"], "4 chromosome-level\nnuclear assemblies", 5.4)
box(0.022, 0.742, 0.20, 0.078, CB["teal"], "STRING v12 PPIs:\n8 Schistosoma species", 5.4)
box(0.246, 0.742, 0.20, 0.078, CB["teal"], "TRPtracker RA data:\n345 variants, 5 countries", 5.4)
box(0.022, 0.664, 0.20, 0.070, CB["green"], "curated behaviour\nlabels + WHO/GBD", 5.4)
box(0.246, 0.664, 0.20, 0.070, CB["purple"], "ERA5 1990–2025 + CMIP6;\n10 palaeo anchors", 5.4)

# --- b: descriptor stack ---
ax.text(0.545, 0.985, "b  Descriptor stack → conditional mapping", fontsize=7.5, fontweight="bold")
layers = [("z$_{seq}$  sequence grammar (k-mers, CpG/TpA, PCA)", CB["blue"]),
          ("z$_{epi}$  interface topology (SmTRPM$_{PZQ}$ locus)", CB["red"]),
          ("z$_{net}$  interaction networks (STRING v12, 8/23)", CB["teal"]),
          ("z$_{eco}$  static ecology (snail, zone, hosts)", CB["green"]),
          ("C(t)  dynamic climate state (ERA5, CMIP6)", CB["purple"])]
for i,(t,c) in enumerate(layers):
    box(0.545, 0.845-i*0.062, 0.24, 0.05, c, t, 6.0)
box(0.815, 0.66, 0.175, 0.30, "#F4F1EA",
    "P(b$_{sch}$ | z, C(t))\n\nb = (H, $\\eta_{inf}$, $\\zeta$, $\\epsilon_{pzq}$,\n$\\Lambda_{ev}$, T$_{pot}$, S$_{clim}$)\n\nvs B$_{fam}$ / B$_{tax}$\n\nLOSO + paired\nbootstrap ΔR", 6.0, ec="#BBBBBB", tc="black")
arrow(0.79, 0.81, 0.813, 0.81)

# --- c: three mechanistic modules + ledger ---
ax.text(0.012, 0.612, "c  Adjudicated modules", fontsize=7.5, fontweight="bold")
box(0.01, 0.40, 0.30, 0.16, CB["red"], "Resistance–fitness tradeoff\n\ns* = b·u/(1−u)\nfield alleles ≤ 2.4× EC50 shift;\nlab-selected 377× — boundary-excluded", 5.8)
box(0.35, 0.40, 0.30, 0.16, CB["purple"], "Quantitative climate projection\n\nERA5-anchored R$_0$(T) + CMIP6 deltas\nChina |Δ|<5% (window redistribution);\nhot African margins −34% to −83%", 5.8)
box(0.69, 0.40, 0.30, 0.16, CB["green"], "Blind hybrid rehearsals\n\nCorsica (miss), Senegal (P=1.00),\nreal Sb×Sc mito (correct 0);\nde novo → abstention by design", 5.8)
arrow(0.16, 0.655, 0.16, 0.565); arrow(0.50, 0.655, 0.50, 0.565); arrow(0.84, 0.655, 0.84, 0.565)

box(0.01, 0.10, 0.98, 0.24, "#F4F1EA",
    "Falsification ledger (Table 1) — every outcome recorded: wins, losses, abstentions\n\n"
    "P1 host range: sequence layer competitive-to-superior (macro-F1 0.475 vs B_tax 0.248; ΔR +0.303 [−0.028, 0.717])   ·   "
    "P1′ human infection: clade-structured; sequence layer point estimate turns positive (0.509 vs 0.405), CI includes zero\n"
    "P2 network layer: real STRING coverage 1/14 → 8/23 (descriptor-level increment quantified)   ·   "
    "P8 TRPtracker empirical test: 92.2% wild type, max field shift 2.4× vs 377× laboratory\n"
    "P4 palaeo anchor: 10 anchors, posterior 0.75 [0.48, 0.94], 1 discordant imported case recorded   ·   "
    "V0 strong Markov axiom falsified (ρ = −0.196, P ≈ 0.002) → grammar conditions on ecology and climate state",
    6.2, ec="#BBBBBB", tc="black")
arrow(0.16, 0.40, 0.16, 0.345); arrow(0.50, 0.40, 0.50, 0.345); arrow(0.84, 0.40, 0.84, 0.345)
plt.tight_layout()
plt.savefig("figures/Fig1_framework.png", dpi=300, bbox_inches="tight")
plt.savefig("figures/Fig1_framework.pdf", bbox_inches="tight")
print("Fig1 done")
