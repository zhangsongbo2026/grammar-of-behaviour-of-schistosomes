#!/usr/bin/env python3
"""E11: network topology descriptors from real STRING v12.0 downloads (score>=700)."""
import gzip, json, os
import networkx as nx

SPECIES = {"6182":"Schistosoma japonicum","6183":"Schistosoma mansoni","6184":"Schistosoma bovis",
 "6185":"Schistosoma haematobium","6186":"Schistosoma curassoni","6188":"Schistosoma rodhaini",
 "31246":"Schistosoma mattheei","48269":"Schistosoma margrebowiei"}

def gz_complete(p):
    try:
        with gzip.open(p,'rt') as f:
            for _ in f: pass
        return True
    except Exception: return False

out = {}
for tax, name in SPECIES.items():
    p = f"data/string/{tax}.protein.links.detailed.v12.0.txt.gz"
    if not os.path.exists(p) or not gz_complete(p):
        print(name, "not complete — skipped for now", flush=True); continue
    G = nx.Graph()
    with gzip.open(p, "rt") as f:
        hdr = f.readline().strip().split(" ")
        si, sj = hdr.index("combined_score"), None
        for line in f:
            p_ = line.rstrip("\n").split(" ")
            if int(p_[-1]) >= 700:
                G.add_edge(p_[0], p_[1])
    n, m = G.number_of_nodes(), G.number_of_edges()
    degs = sorted(dict(G.degree()).values(), reverse=True)
    dens = 2*m/(n*(n-1)) if n>1 else 0
    import random; random.seed(42)
    if n > 3000:
        sub = random.sample(list(G.nodes), 3000)
        cc = nx.average_clustering(G.subgraph(sub))
    else:
        cc = nx.average_clustering(G)
    out[name] = {"taxid":tax,"nodes":n,"edges":m,"density":round(dens,7),
                 "mean_degree":round(2*m/max(n,1),2),"max_degree":degs[0],
                 "top20_share":round(sum(degs[:20])/max(2*m,1),4),"clustering":round(cc,4)}
    print(name, out[name], flush=True)
json.dump(out, open("results/e11_string_topology.json","w"), indent=1)
print("coverage:", len(out), "of 8 STRING species; 8 of 23 panel taxa")
