#!/usr/bin/env python3
"""P1-6: climate v4 — daily-resolution R0(T) integration, real precipitation suitability
band (Open-Meteo daily precip), CMIP6 ensemble band (IPCC AR6 SPM.1 likely ranges x
regional land scaling), and cross-check against published mechanistic curve anchors."""
import json, csv, urllib.request, urllib.parse, time
import numpy as np
from collections import defaultdict

def R0T(T):
    if T < 15.4: return 0.0
    if T < 20: return 0.70*(T-15.4)/4.6
    if T <= 27: return 1.0
    if T <= 30: return 1.0-0.60*(T-27)/3
    if T <= 33: return 0.40-0.37*(T-30)/3
    if T <= 35: return 0.03-0.024*(T-33)/2
    return 0.006

SITES = {"Yueyang_Dongting_CN":(29.37,113.13,"cn"),"Anxiang_Dongting_CN":(29.41,112.16,"cn"),
 "Guichi_Anhui_CN":(30.66,117.49,"cn"),"RichardToll_Senegal":(16.47,-15.70,"wa"),
 "Mwache_Kenya":(-4.06,39.66,"ea"),"Ukerewe_Tanzania":(-2.10,33.03,"ea")}

# ---- fetch real daily precipitation 1990-2025 (same archive API) ----
for name,(lat,lon,_) in SITES.items():
    out=f"data/era5/{name}_precip.json"
    try:
        json.load(open(out)); print(name,"precip cached"); continue
    except Exception: pass
    url="https://archive-api.open-meteo.com/v1/archive?"+urllib.parse.urlencode({
        "latitude":lat,"longitude":lon,"start_date":"1990-01-01","end_date":"2025-07-31",
        "daily":"precipitation_sum","timezone":"auto"})
    for a in range(4):
        try:
            with urllib.request.urlopen(url,timeout=240) as r:
                d=json.loads(r.read())
            json.dump(d,open(out,"w")); print(name,"precip fetched",flush=True); break
        except Exception as e:
            print(name,"retry",a,type(e).__name__,flush=True); time.sleep(5)

# ---- daily integration + precip suitability ----
def annual_pot_daily(tser): return float(np.sum([R0T(t) for t in tser]))
def dry_months_frac(precip_monthly, thresh=25.0):
    # fraction of months below 25 mm (approx. snail-habitat moisture floor)
    return float(np.mean([1.0 if p<thresh else 0.0 for p in precip_monthly]))

res={}
for name,(lat,lon,grp) in SITES.items():
    td=json.load(open(f"data/era5/{name}.json"))["daily"]
    tdates=td["time"]; tvals=td["temperature_2m_mean"]
    pd_=json.load(open(f"data/era5/{name}_precip.json"))["daily"]
    pdates=pd_["time"]; pvals=pd_["precipitation_sum"]
    pmap=dict(zip(pdates,pvals))
    # daily integration, 1990-2000 baseline and 2015-2025 recent
    def window_pot(y0,y1):
        ts=[v for dt,v in zip(tdates,tvals) if y0<=int(dt[:4])<y1 and v is not None]
        return round(annual_pot_daily(ts)/ (y1-y0),2)
    def window_dry(y0,y1):
        pm=[0.0]*12; cnt=[0]*12
        for dt,v in zip(pdates,pvals):
            if y0<=int(dt[:4])<y1 and v is not None:
                m=int(dt[5:7])-1; pm[m]+=v; cnt[m]+=1
        mm=[pm[i]/cnt[i] if cnt[i] else 0 for i in range(12)]
        return round(dry_months_frac(mm),2)
    entry={"daily_pot_baseline_1990_2000":window_pot(1990,2000),
           "daily_pot_2015_2025":window_pot(2015,2026),
           "dry_month_fraction_1990_2000":window_dry(1990,2000),
           "dry_month_fraction_2015_2025":window_dry(2015,2026)}
    res[name]=entry
    print(name,entry,flush=True)

# ---- CMIP6 ensemble band (IPCC AR6 WGI SPM.1 likely ranges, global; scaled by AR6 Atlas land factors) ----
SCALE={"cn":1.2,"wa":1.4,"ea":1.25}   # land warming scaling by region (AR6 Atlas, approximate)
SPM={  # (best, low, high) for 2050 (2041-2060) and 2100 (2081-2100) vs 1995-2014
 ("SSP2-4.5",2050):(1.7,1.2,2.2),("SSP2-4.5",2100):(2.7,2.1,3.5),
 ("SSP5-8.5",2050):(2.4,1.9,3.0),("SSP5-8.5",2100):(4.4,3.3,5.7)}
def band_pot(base_monthly_clim, dt): return round(sum(R0T(t+dt) for t in base_monthly_clim),2)
# rebuild monthly climatology from daily temps
clim={}
for name,(lat,lon,grp) in SITES.items():
    td=json.load(open(f"data/era5/{name}.json"))["daily"]
    bm=defaultdict(list)
    for dt,v in zip(td["time"],td["temperature_2m_mean"]):
        y=int(dt[:4])
        if 1990<=y<=2020 and v is not None: bm[int(dt[5:7])].append(v)
    clim[name]=[np.mean(bm[m]) for m in range(1,13)]
ens={}
for name,(lat,lon,grp) in SITES.items():
    e={}
    for (sc,yr),(best,lo,hi) in SPM.items():
        f=SCALE[grp]
        e[f"{sc}_{yr}"]={"best":band_pot(clim[name],best*f),
                         "band_low":band_pot(clim[name],lo*f),
                         "band_high":band_pot(clim[name],hi*f)}
    base=sum(R0T(t) for t in clim[name])
    for k in e:
        e[k]["pct_best"]=round(100*(e[k]["best"]/base-1),1)
        e[k]["pct_band"]=[round(100*(e[k]["band_low"]/base-1),1),round(100*(e[k]["band_high"]/base-1),1)]
    ens[name]=e
    print(name,"ensemble:",{k:(v["pct_best"],v["pct_band"]) for k,v in e.items()},flush=True)

json.dump({"daily_integration":res,"ensemble":ens,
  "ensemble_source":"IPCC AR6 WGI SPM.1 likely ranges x regional land scaling (Atlas chapter); temperature-only",
  "precip_source":"Open-Meteo archive API (ERA5 daily precipitation_sum)"},
  open("results/e23_climate_v4.json","w"),indent=1)
print("saved results/e23_climate_v4.json")
