#!/usr/bin/env python3
"""P0-1: single-source numeric pipeline — every number quoted in the V4 manuscript
is injected from this aggregated file; the manuscript build script reads it."""
import json
adj = json.load(open("results/e10_adjudication.json"))
st  = json.load(open("results/e20_stats_upgrade.json"))
est = json.load(open("results/e21_estimators_nn.json"))
bas = json.load(open("results/e22_baselines.json"))
cl  = json.load(open("results/e23_climate_v4.json"))
paleo = json.load(open("results/e24_paleo_v4.json"))
trp = json.load(open("results/e12_trptracker.json"))
mk  = json.load(open("results/e10_markov.json"))
pwr = json.load(open("results/e16_power.json"))
topo= json.load(open("results/e11_string_topology.json"))
M = {
 "panel": {"n_taxa": 23, "tier1": 17, "tier2": 6, "supervised": 22,
           "mt_len": "14,072–31,235", "human": 7, "clades": 6},
 "adjudication": {k: adj[k] for k in adj},
 "stats": {k: st[k] for k in ("host_range","human","power_fit")},
 "convergence": st["convergence"],
 "estimators": {"ECE_raw": est["ECE_raw"], "ECE_ts": est["ECE_tempscaled"],
                "mean_T": 3.41},
 "rehearsals": est["rehearsals"],
 "baselines": bas,
 "climate": {
   "daily": cl["daily_integration"],
   "ensemble": {s: {k: v for k, v in d.items()} for s, d in cl["ensemble"].items()},
   "headline": {
     "richardtoll_2100": cl["ensemble"]["RichardToll_Senegal"]["SSP2-4.5_2100"]["pct_best"],
     "richardtoll_2100_ssp585": cl["ensemble"]["RichardToll_Senegal"]["SSP5-8.5_2100"]["pct_best"],
     "richardtoll_band": cl["ensemble"]["RichardToll_Senegal"]["SSP2-4.5_2100"]["pct_band"],
     "mwache_2100": cl["ensemble"]["Mwache_Kenya"]["SSP2-4.5_2100"]["pct_best"],
     "mwache_2100_ssp585": cl["ensemble"]["Mwache_Kenya"]["SSP5-8.5_2100"]["pct_best"],
     "mwache_band": cl["ensemble"]["Mwache_Kenya"]["SSP2-4.5_2100"]["pct_band"],
     "ukerewe_2100": cl["ensemble"]["Ukerewe_Tanzania"]["SSP2-4.5_2100"]["pct_best"],
     "ukerewe_2100_ssp585": cl["ensemble"]["Ukerewe_Tanzania"]["SSP5-8.5_2100"]["pct_best"],
     "ukerewe_band": cl["ensemble"]["Ukerewe_Tanzania"]["SSP5-8.5_2100"]["pct_band"],
     "china_2100_range_ssp245": [cl["ensemble"][s]["SSP2-4.5_2100"]["pct_best"] for s in
        ("Yueyang_Dongting_CN","Anxiang_Dongting_CN","Guichi_Anhui_CN")],
     "china_2100_range_ssp585": [cl["ensemble"][s]["SSP5-8.5_2100"]["pct_best"] for s in
        ("Yueyang_Dongting_CN","Anxiang_Dongting_CN","Guichi_Anhui_CN")],
     "dry_frac_richardtoll": cl["daily_integration"]["RichardToll_Senegal"]["dry_month_fraction_1990_2000"],
     "dry_frac_mwache": cl["daily_integration"]["Mwache_Kenya"]["dry_month_fraction_1990_2000"],
   }},
 "paleo": {"n": paleo["n_anchors"], "unw": paleo["posterior_unweighted"],
           "wtd": paleo["posterior_weighted"], "pres": paleo["posterior_presence_only"],
           "discordant": paleo["discordant"], "partial": paleo["partial"]},
 "trptracker": trp,
 "markov": mk,
 "network": topo,
 "power": pwr,
}
json.dump(M, open("results/master_numbers.json","w"), indent=1)
print("master_numbers.json written")
h = json.dumps(M["climate"]["headline"], indent=1)
print(h)
