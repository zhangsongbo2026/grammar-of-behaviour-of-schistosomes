#!/usr/bin/env python3
"""E10/E16: expanded-panel sequence layer, LOSO adjudication, Markov budget,
hybrid rehearsals, power analysis. All sequence data are real (NCBI downloads)."""
import csv, json, math, itertools
import numpy as np
from collections import Counter

rng = np.random.default_rng(42)

# ---------- 1. descriptors from real FASTA ----------
def read_fasta(path):
    seq = "".join(l.strip() for l in open(path) if not l.startswith(">")).upper()
    return seq

def descriptors(seq):
    n = len(seq)
    gc = (seq.count("G") + seq.count("C")) / n
    a = seq.count("A"); c = seq.count("C"); g = seq.count("G"); t = seq.count("T")
    at_skew = (a - t) / (a + t) if (a + t) else 0.0
    gc_skew = (g - c) / (g + c) if (g + c) else 0.0
    din = {}
    din_obs = Counter(seq[i:i+2] for i in range(n-1))
    mono = {"A":a,"C":c,"G":g,"T":t}
    odds = {}
    for x in "ACGT":
        for y in "ACGT":
            exp = mono[x]*mono[y]/(n-1)
            odds[x+y] = din_obs[x+y]/exp if exp>0 else 1.0
    k4 = Counter(seq[i:i+4] for i in range(n-3))
    k4vec = np.zeros(256)
    for i, kmer in enumerate(["".join(p) for p in itertools.product("ACGT", repeat=4)]):
        k4vec[i] = k4.get(kmer, 0)
    k4n = k4vec/ (n-3)
    return {"len":n, "gc":gc, "at_skew":at_skew, "gc_skew":gc_skew,
            "odds":odds, "k4":k4n}

PANEL = {r["taxon"]: r for r in csv.DictReader(open("data/panel_labels.csv"))}
FEAT = {}
for tax, r in PANEL.items():
    seq = read_fasta(f"data/fasta/{tax.replace(chr(32), chr(95))}.fasta")
    FEAT[tax] = descriptors(seq)
    r["mt_len"] = len(seq)

BASE = ["gc","at_skew","gc_skew"] + ["odds_"+k for k in ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")]
def base_vector(f):
    return [f["gc"], f["at_skew"], f["gc_skew"]] + [f["odds"][k] for k in ("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")]

def k4_std_matrix(taxes):
    M = np.array([FEAT[t]["k4"] for t in taxes])
    return (M - M.mean(0)) / (M.std(0) + 1e-12)

TAXES = list(PANEL)
k4s = k4_std_matrix(TAXES)
pca5 = {}
# PCA via SVD on tier1 only (complete genomes); tier2 gets median imputation
tier1 = [i for i,t in enumerate(TAXES) if PANEL[t]["tier"]=="tier1"]
X1 = k4s[tier1]
mean = X1.mean(0); Xc = X1 - mean
U,S,Vt = np.linalg.svd(Xc, full_matrices=False)
comp = Vt[:5]
for i,t in enumerate(TAXES):
    if PANEL[t]["tier"]=="tier1":
        pca5[t] = (k4s[i]-mean) @ comp.T
med5 = np.median(np.array([pca5[t] for t in TAXES if t in pca5]), axis=0)
for t in TAXES:
    if t not in pca5: pca5[t] = med5

def seq_vector(t, tier="all"):
    f = FEAT[t]
    v = base_vector(f)
    if tier=="all":
        v = v + list(pca5[t])
    return np.array(v)

def dist_vec(t1, t2):
    return np.linalg.norm(seq_vector(t1) - seq_vector(t2))

def behaviour(t):
    r = PANEL[t]
    return r

def behav_dist(t1, t2):
    r1, r2 = PANEL[t1], PANEL[t2]
    h1, h2 = math.log10(int(r1["def_host_count"])), math.log10(int(r2["def_host_count"]))
    # min-max normalize over panel
    hcs = [math.log10(int(PANEL[x]["def_host_count"])) for x in TAXES]
    hmin, hmax = min(hcs), max(hcs)
    h = abs(h1-h2)/(hmax-hmin) if hmax>hmin else 0
    hum = abs(int(r1["human_infecting"])-int(r2["human_infecting"]))
    z = abs(float(r1["zoonotic"])-float(r2["zoonotic"]))
    return math.sqrt(h*h + hum*hum + z*z)

def eco_dist(t1, t2):
    r1, r2 = PANEL[t1], PANEL[t2]
    s = 0.0
    s += 0 if r1["snail_genus"]==r2["snail_genus"] else 1
    s += 0 if r1["climate_zone"]==r2["climate_zone"] else 1
    return s

# structural distance matrix over standardized 4-mer spectra
D = {}
for t1, t2 in itertools.combinations(TAXES, 2):
    D[(t1,t2)] = D[(t2,t1)] = float(np.linalg.norm(k4s[TAXES.index(t1)] - k4s[TAXES.index(t2)]))

# ---------- 2. approximate-Markov budget ----------
pairs = list(itertools.combinations(TAXES, 2))
sd = [D[(t1,t2)] for t1,t2 in pairs]
bd = [behav_dist(t1,t2) for t1,t2 in pairs]
ed = [eco_dist(t1,t2) for t1,t2 in pairs]
def spearman(x,y):
    def rank(v):
        order = np.argsort(v); r = np.empty(len(v))
        for i, idx in enumerate(order): r[idx] = i
        return r
    rx, ry = rank(x), rank(y)
    rx = (rx-rx.mean())/(rx.std()+1e-12); ry=(ry-ry.mean())/(ry.std()+1e-12)
    return float((rx*ry).mean())
rho_sb = spearman(sd, bd)
# partial given ecology: spearman of residuals via rank-regression
def rank(v):
    order = np.argsort(v); r = np.empty(len(v))
    for i, idx in enumerate(order): r[idx]=i
    return r
rs, rb, re = rank(sd), rank(bd), rank(ed)
def resid(y, X):
    X1 = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(X1, y, rcond=None)
    return y - X1@beta
res_sb = resid(rb, re[:,None]); res_eb = resid(re, rb[:,None])
# partial rho = corr(resid(rb|re), resid(re|rb))  -- standard: corr(resid of sb on ed, resid of ed? ) use double-residualization
r1_ = resid(rb, re[:,None]); r2_ = resid(rs, re[:,None])
rho_sb_eco = float(np.corrcoef(r1_, r2_)[0,1])
# permutation p
perm_p = 0
R = 10000
for _ in range(R):
    idx = rng.permutation(len(sd))
    if spearman([sd[i] for i in idx], bd) >= rho_sb: perm_p += 1
perm_p /= R
# near-structural clade residual
thr = np.quantile(sd, 0.25)
near = [(t1,t2) for (t1,t2) in pairs if D[(t1,t2)] <= thr]
within, across = [], []
for t1,t2 in near:
    v = behav_dist(t1,t2)/max(np.mean(bd),1e-9)
    (within if PANEL[t1]["clade"]==PANEL[t2]["clade"] else across).append(v)
epsM = abs(np.mean(within or [0]) - np.mean(across or [0]))/max(np.mean(across or [1]),1e-9)

markov = {"n_pairs": len(pairs), "rho_struct_behav": round(rho_sb,3), "perm_p": round(perm_p,4),
          "partial_rho_given_eco": round(rho_sb_eco,3),
          "near_within": round(float(np.mean(within)),3) if within else None,
          "near_across": round(float(np.mean(across)),3) if across else None,
          "n_near_within": len(within), "n_near_across": len(across), "epsM_sch": round(epsM,4)}
json.dump(markov, open("results/e10_markov.json","w"), indent=1)
print("MARKOV:", markov)

# distance matrix for figure
json.dump({"taxes": TAXES, "D": {f"{a}|{b}": D[(a,b)] for a,b in D}, "k4s": k4s.tolist(),
           "gc": {t: FEAT[t]["gc"] for t in TAXES}, "len": {t: FEAT[t]["len"] for t in TAXES},
           "cpg": {t: FEAT[t]["odds"]["CG"] for t in TAXES}},
          open("results/e10_dist.json","w"))

# ---------- 3. LOSO adjudication ----------
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler

def macro_f1_loso(taxes, feats, target, est, **ekw):
    yv = {t: (int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"]) for t in taxes}
    scores = []
    for held in taxes:
        tr = [t for t in taxes if t != held]
        Xtr = np.array([feats[t] for t in tr]); ytr = [yv[t] for t in tr]
        Xte = feats[held].reshape(1,-1)
        if est=="gb":
            m = GradientBoostingClassifier(n_estimators=100, max_depth=2, random_state=42)
        else:
            m = LogisticRegression(C=1.0, solver="liblinear", random_state=42, max_iter=5000)
        try:
            m.fit(Xtr, ytr); p = m.predict(Xte)[0]
        except Exception:
            p = Counter(ytr).most_common(1)[0][0]
        scores.append((held, p, yv[held]))
    ytrue = [s[2] for s in scores]; ypred = [s[1] for s in scores]
    return f1_score(ytrue, ypred, average="macro"), scores

def B_fam(taxes, target):
    yv = [int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"] for t in taxes]
    maj = Counter(yv).most_common(1)[0][0]
    ypred = [maj]*len(yv)
    return f1_score(yv, ypred, average="macro"), yv, ypred

def B_tax(taxes, target, held=None):
    yv = {t: (int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"]) for t in taxes}
    ypred, ytrue = [], []
    for held in taxes:
        tr = [t for t in taxes if t != held]
        maj = Counter(yv[t] for t in tr).most_common(1)[0][0]
        ypred.append(maj); ytrue.append(yv[held])
    return f1_score(ytrue, ypred, average="macro"), ytrue, ypred

# feature blocks
def feats_all(t):  # zseq full: base + PCA5
    return seq_vector(t, "all")
def feats_base(t): # base only (available for all tiers)
    return seq_vector(t, "base")
def feats_eco(t):
    r = PANEL[t]
    gens = ["Biomphalaria","Bulinus","Oncomelania","Neotricula","Indoplanorbis","Radix","Tricula","unknown"]
    zones = ["tropical","subtropical","temperate"]
    return np.array([1.0 if r["snail_genus"]==g else 0.0 for g in gens] +
                    [1.0 if r["climate_zone"]==z else 0.0 for z in zones])
def feats_comb(t):
    return np.concatenate([feats_all(t), feats_eco(t)])

BLOCKS = {"z_seq": feats_all, "z_seq_base": feats_base, "z_eco": feats_eco, "combined": feats_comb}
supervised = [t for t in TAXES if t != "Hybrid_S.bovis_x_S.curassoni"]

results = {}
for target in ("host_range","human"):
    for bname, bfn in BLOCKS.items():
        for est in ("gb","log"):
            for subset, name in ((supervised, "n22"), (supervised[:14], "n14core")):
                pass
    # run all
    for bname, bfn in BLOCKS.items():
        for est in ("gb","log"):
            f1, scores = macro_f1_loso(supervised, {t: bfn(t) for t in supervised}, target, est)
            results[f"{target}|{bname}|{est}"] = {"macro_f1": round(f1,3)}
    f1fam, _, _ = B_fam(supervised, target)
    f1tax, yt, yp = B_tax(supervised, target)
    results[f"{target}|B_fam"] = {"macro_f1": round(f1fam,3)}
    results[f"{target}|B_tax"] = {"macro_f1": round(f1tax,3)}
print(json.dumps(results, indent=1))
json.dump(results, open("results/e10_loso_n22.json","w"), indent=1)

# paired bootstrap ΔR vs B_tax using LOSO score vectors (n22, gb)
def deltaR_ci(target, bname, est="gb", n_boot=10000):
    f1, scores = macro_f1_loso(supervised, {t: BLOCKS[bname](t) for t in supervised}, target, est)
    ytrue = np.array([s[2] for s in scores]); ypred = np.array([s[1] for s in scores])
    ftax, yt, yp = B_tax(supervised, target)
    yt = np.array(yt); yp = np.array(yp)
    ris = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(ytrue), len(ytrue))
        def mf(yt2, yp2):
            if len(np.unique(yt2))<2: return np.nan
            return f1_score(yt2, yp2, average="macro")
        a = mf(ytrue[idx], ypred[idx]); b = mf(yt[idx], yp[idx])
        if np.isnan(a) or np.isnan(b) or b==0: continue
        ris.append(1 - a/b)
    ris = np.array(ris)
    return {"deltaR": round(float(1 - f1/ftax),3),
            "ci": [round(float(np.quantile(ris,0.025)),3), round(float(np.quantile(ris,0.975)),3)],
            "f1": round(f1,3), "f1_btax": round(ftax,3)}
drs = {}
for target in ("host_range","human"):
    for bname in ("z_seq","z_seq_base","z_eco","combined"):
        drs[f"{target}|{bname}"] = deltaR_ci(target, bname)
print(json.dumps(drs, indent=1))
json.dump(drs, open("results/e10_deltaR_n22.json","w"), indent=1)
