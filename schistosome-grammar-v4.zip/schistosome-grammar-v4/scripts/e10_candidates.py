import json, urllib.request, urllib.parse, time
def esearch(term, retmax=300):
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?" + urllib.parse.urlencode({
        "db": "nuccore", "term": term, "retmax": retmax, "retmode": "json"})
    for a in range(3):
        try:
            with urllib.request.urlopen(url, timeout=45) as r:
                return json.loads(r.read())["esearchresult"].get("idlist", [])
        except Exception as e:
            time.sleep(3)
    return []

orgs = ["Schistosoma mansoni","Schistosoma rodhaini","Schistosoma haematobium","Schistosoma bovis",
 "Schistosoma curassoni","Schistosoma guineensis","Schistosoma intercalatum","Schistosoma mattheei",
 "Schistosoma margrebowiei","Schistosoma japonicum","Schistosoma mekongi","Schistosoma malayensis",
 "Schistosoma spindale","Schistosoma indicum","Schistosoma nasale","Schistosoma incognitum",
 "Schistosoma turkestanicum","Orientobilharzia turkestanicum","Schistosoma sinensium","Schistosoma edwardiense",
 "Schistosoma hippopotami","Schistosoma leiperi","Schistosoma kisumuensis","Schistosoma ovuncatum",
 "Schistosoma congolensis","Trichobilharzia regenti","Trichobilharzia szidati","Trichobilharzia physella",
 "Heterobilharzia americana","Gigantobilharzia acotylea","Gigantobilharzia huronensis","Ornithobilharzia canaliculata",
 "Dendritobilharzia pulverulenta","Schistosoma haematobium x Schistosoma bovis"]
cand = {}
for o in orgs:
    term = f'"{o}"[Organism] AND mitochondrion[Filter] AND ("complete genome"[Title] OR "complete sequence"[Title] OR "complete genome"[Filter])'
    ids = esearch(term)
    cand[o] = ids
    print(len(ids), o, flush=True)
    time.sleep(0.5)
json.dump(cand, open("data/mt_candidates.json","w"), indent=1)
