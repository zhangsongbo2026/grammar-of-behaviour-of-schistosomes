#!/usr/bin/env python3
"""Expert B 3.1: baseline comparison suite — RF, L2-logistic, kNN, GaussianNB vs GB,
same LOSO folds, paired permutation tests (Expert A 2a logic)."""
import csv, json
import numpy as np
from collections import Counter
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import f1_score

rng=np.random.default_rng(5)
PANEL={r["taxon"]:r for r in csv.DictReader(open("data/panel_labels.csv"))}
dist=json.load(open("results/e10_dist.json"))
TAXES=dist["taxes"]; k4s=np.array(dist["k4s"])
supervised=[t for t in TAXES if t!="Hybrid_S.bovis_x_S.curassoni"]
BASE_KEYS=("AA","AT","AG","AC","TA","TT","TG","TC","GA","GT","GG","GC","CA","CT","CG","CC")
def base_vector(t):
    seq="".join(l.strip() for l in open(f"data/fasta/{t.replace(chr(32),chr(95))}.fasta") if not l.startswith(">")).upper()
    n=len(seq);a=seq.count("A");c=seq.count("C");g=seq.count("G");tt=seq.count("T")
    obs=Counter(seq[i:i+2] for i in range(n-1));mono={"A":a,"C":c,"G":g,"T":tt}
    odds={k:obs[k]/(mono[k[0]]*mono[k[1]]/(n-1)) for k in (x+y for x in "ACGT" for y in "ACGT")}
    return np.array([(g+c)/n,(a-tt)/(a+tt),(g-c)/(g+c)]+[odds[k] for k in BASE_KEYS])
t1=[i for i,t in enumerate(TAXES) if PANEL[t]["tier"]=="tier1"]
X=k4s[t1];mn=X.mean(0);U,S,Vt=np.linalg.svd(X-mn,full_matrices=False);comp=Vt[:5]
med=np.median((X-mn)@comp.T,axis=0)
def feats(t):
    b=base_vector(t)
    p=(k4s[TAXES.index(t)]-mn)@comp.T if PANEL[t]["tier"]=="tier1" else med
    return np.concatenate([b,p])
MODELS={
 "GB":lambda:GradientBoostingClassifier(n_estimators=100,max_depth=2,random_state=42),
 "RF":lambda:RandomForestClassifier(n_estimators=500,random_state=42),
 "L2_logistic":lambda:LogisticRegression(C=1.0,max_iter=5000,random_state=42),
 "kNN5":lambda:KNeighborsClassifier(5),
 "GaussianNB":lambda:GaussianNB(),
}
def ytar(t,target): return int(PANEL[t]["human_infecting"]) if target=="human" else PANEL[t]["host_range_class"]
out={}
for target in ("host_range","human"):
    scores={}
    for name,mk in MODELS.items():
        yp,yt=[],[]
        yv={t:ytar(t,target) for t in supervised}
        for held in supervised:
            tr=[t for t in supervised if t!=held]
            m=mk();m.fit(np.array([feats(t) for t in tr]),[yv[t] for t in tr])
            yp.append(m.predict(np.array([feats(held)]))[0]);yt.append(yv[held])
        scores[name]=(yt,yp)
    # B_tax
    yv={t:ytar(t,target) for t in supervised}
    yp,yt=[],[]
    for held in supervised:
        tr=[t for t in supervised if t!=held]
        yp.append(Counter(yv[t] for t in tr).most_common(1)[0][0]);yt.append(yv[held])
    scores["B_tax"]=(yt,yp)
    row={}
    ytv,ypv=scores["GB"]
    for name,(a,b) in scores.items():
        row[name]=round(float(f1_score(a,b,average="macro")),3)
    # paired permutation GB vs each
    for name in ("RF","L2_logistic","kNN5","GaussianNB","B_tax"):
        a2,b2=scores[name]
        ya,ypa=scores["GB"]
        n=len(ya);null=[]
        sw=rng.random((20000,n))<0.5
        ya_a=np.array(ya);ypa_a=np.array(ypa);a2a=np.array(a2);b2a=np.array(b2)
        for r_ in sw[:20000]:
            m1=np.where(r_,ypa_a,b2a);m2=np.where(r_,b2a,ypa_a)
            null.append(f1_score(ya_a,m1,average="macro")-f1_score(ya_a,m2,average="macro"))
        null=np.array(null);obs=f1_score(ya,ypa,average="macro")-f1_score(a2,b2,average="macro")
        row[f"p_vs_{name}"]=round(float((np.sum(null>=obs)+1)/(len(null)+1)),4)
        row[f"dF1_vs_{name}"]=round(float(obs),3)
    out[target]=row
    print(target,row,flush=True)
json.dump(out,open("results/e22_baselines.json","w"),indent=1)
