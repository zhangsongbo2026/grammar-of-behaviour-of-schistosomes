#!/usr/bin/env python3
"""Build VITS2 docx: pandoc -> OMML, then schema fixes per playbook, then
independent lxml XSD validation (target: 0 errors)."""
import zipfile, shutil, subprocess, re, sys, os
from lxml import etree

MD = "manuscript/manuscript_v4.md"
OUT = "manuscript/Schistosomiasis_Grammar_V4.docx"
SCHEMA = "/app/skills/docx/scripts/office/schemas/ISO-IEC29500-4_2016/wml.xsd"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"

def run_pandoc():
    cmd = ["pandoc", MD, "-o", OUT, "--resource-path=.:manuscript",
           "--from=markdown+tex_math_dollars+raw_tex", "--to=docx"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("PANDOC FAIL:", r.stderr[:3000]); sys.exit(1)
    print("pandoc OK")

def parse(part):
    return etree.fromstring(part)

def ser(root):
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)

MATH_RPR_ORDER = ["lit", "nor", "scr", "sty", "brk", "aln"]

def fix_math_rpr(root):
    n = 0
    for rpr in root.iter("{%s}rPr" % M):
        kids = list(rpr)
        def key(k):
            tag = etree.QName(k).localname
            return MATH_RPR_ORDER.index(tag) if tag in MATH_RPR_ORDER else 99
        skids = sorted(kids, key=key)
        if skids != kids:
            for k in kids: rpr.remove(k)
            for k in skids: rpr.append(k)
            n += 1
        # nor/sty conflict: drop sty
        tags = [etree.QName(k).localname for k in rpr]
        if "nor" in tags and "sty" in tags:
            for k in rpr:
                if etree.QName(k).localname == "sty":
                    rpr.remove(k); n += 1; break
    return n

PPR_ORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl",
             "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens",
             "kinsoku", "wordWrap", "overflowPunct", "topLinePunct", "autoSpaceDE",
             "autoSpaceDN", "bidi", "adjustRightInd", "snapToGrid", "spacing", "ind",
             "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc", "textDirection",
             "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr",
             "sectPr", "pPrChange"]

def fix_ppr(root, ns):
    n = 0
    for tag in ("pPr",):
        for ppr in root.iter("{%s}%s" % (ns, tag)):
            kids = list(ppr)
            def key(k):
                t = etree.QName(k).localname
                return PPR_ORDER.index(t) if t in PPR_ORDER else 98
            skids = sorted(kids, key=key)
            if skids != kids:
                for k in kids: ppr.remove(k)
                for k in skids: ppr.append(k)
                n += 1
    return n

RPR_ORDER = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike",
             "dstrike", "outline", "shadow", "emboss", "imprint", "noProof", "snapToGrid",
             "vanish", "webHidden", "color", "spacing", "w", "kern", "position", "sz",
             "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText", "vertAlign",
             "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath"]

def fix_rpr(root, ns):
    n = 0
    for rpr in root.iter("{%s}rPr" % ns):
        kids = list(rpr)
        def key(k):
            t = etree.QName(k).localname
            return RPR_ORDER.index(t) if t in RPR_ORDER else 98
        skids = sorted(kids, key=key)
        if skids != kids:
            for k in kids: rpr.remove(k)
            for k in skids: rpr.append(k)
            n += 1
    return n

def fix_content_types(z):
    ct = z.read("[Content_Types].xml").decode()
    add = ""
    if 'Extension="png"' not in ct: add += '<Default Extension="png" ContentType="image/png"/>'
    if 'Extension="jpeg"' not in ct: add += '<Default Extension="jpeg" ContentType="image/jpeg"/>'
    if add:
        ct = ct.replace("</Types>", add + "</Types>")
        z.writestr("[Content_Types].xml", ct)
        print("content-types patched")

SETTINGS_ORDER = ["writeProtection","view","zoom","removePersonalInformation","removeDateAndTime",
    "doNotDisplayPageBoundaries","displayBackgroundShape","printPostScriptOverText",
    "printFractionalCharacterWidth","printFormsData","embedTrueTypeFonts","embedSystemFonts",
    "saveSubsetFonts","saveFormsData","mirrorMargins","alignBordersAndEdges","bordersDoNotSurroundHeader",
    "bordersDoNotSurroundFooter","gutterAtTop","hideSpellingErrors","hideGrammaticalErrors",
    "activeWritingStyle","proofState","formsDesign","attachedTemplate","linkStyles","stylePaneFormatFilter",
    "stylePaneSortMethod","documentType","mailMerge","revisionView","trackChanges","doNotTrackMoves",
    "doNotTrackFormatting","documentProtection","autoFormatOverride","styleLockTheme","styleLockQFSet",
    "defaultTabStop","autoHyphenation","consecutiveHyphenLimit","hyphenationZone","doNotHyphenateCaps",
    "showEnvelope","summaryLength","clickAndTypeStyle","defaultTableStyle","evenAndOddHeaders",
    "bookFoldRevPrinting","bookFoldPrinting","bookFoldPrintingSheets","drawingGridHorizontalSpacing",
    "drawingGridVerticalSpacing","displayHorizontalDrawingGridEvery","displayVerticalDrawingGridEvery",
    "doNotUseMarginsForDrawingGridOrigin","drawingGridHorizontalOrigin","drawingGridVerticalOrigin",
    "doNotShadeFormData","noPunctuationKerning","characterSpacingControl","printTwoOnOne",
    "strictFirstAndLastChars","noLineBreaksAfter","noLineBreaksBefore","savePreviewPicture",
    "doNotValidateAgainstSchema","saveInvalidXml","ignoreMixedContent","alwaysShowPlaceholderText",
    "doNotDemarcateInvalidXml","saveXmlDataOnly","useXSLTWhenSaving","saveThroughXslt",
    "showXMLTags","alwaysMergeEmptyNamespace","updateFields","hdrShapeDefaults","footnotePr",
    "endnotePr","compat","docVars","rsids","mathPr","attachedSchema","themeFontLang","clrSchemeMapping",
    "doNotIncludeSubdocsInStats","doNotAutoCompressPictures","forceUpgrade","captions","readModeInkLockDown",
    "smartTagType","shapeDefaults","doNotEmbedSmartTags","decimalSymbol","listSeparator"]

def fix_settings(z):
    xml = z.read("word/settings.xml")
    root = etree.fromstring(xml)
    kids = list(root)
    def key(k):
        t = etree.QName(k).localname
        return SETTINGS_ORDER.index(t) if t in SETTINGS_ORDER else 98
    # dedup proofState
    seen, to_remove = set(), []
    for k in kids:
        t = etree.QName(k).localname
        if t == "proofState":
            if "proofState" in seen: to_remove.append(k)
            seen.add("proofState")
    for k in to_remove: root.remove(k)
    kids = list(root)
    skids = sorted(kids, key=key)
    if skids != kids:
        for k in kids: root.remove(k)
        for k in skids: root.append(k)
    z.writestr("word/settings.xml", ser(root))
    print("settings fixed (removed %d dup proofState)" % len(to_remove))

def fix_styles(z):
    xml = z.read("word/styles.xml")
    root = etree.fromstring(xml)
    # qFormat must come after basedOn/next/link and before pPr
    n = 0
    for st in root.iter("{%s}style" % W):
        kids = list(st)
        names = [etree.QName(k).localname for k in kids]
        if "qFormat" in names:
            idx = names.index("qFormat")
            # position: after name/basedOn/next/link/uiPriority, before pPr
            pre = [k for k in kids if etree.QName(k).localname in
                   ("name","aliases","basedOn","next","link","autoRedefine","hidden","uiPriority","semiHidden","unhideWhenUsed")]
            post = [k for k in kids if k not in pre and etree.QName(k).localname != "qFormat"]
            qf = [k for k in kids if etree.QName(k).localname == "qFormat"]
            newkids = pre + qf + post
            if newkids != kids:
                for k in kids: st.remove(k)
                for k in newkids: st.append(k)
                n += 1
    z.writestr("word/styles.xml", ser(root))
    print("styles fixed (%d styles)" % n)

def validate(doc_xml_bytes):
    schema_doc = etree.parse(SCHEMA)
    schema = etree.XMLSchema(schema_doc)
    doc = etree.fromstring(doc_xml_bytes)
    ok = schema.validate(doc)
    errs = schema.error_log
    return ok, list(errs)[:20], len(schema.error_log)

def main():
    run_pandoc()
    zin = zipfile.ZipFile(OUT)
    parts = {n: zin.read(n) for n in zin.namelist()}
    zin.close()

    # document.xml fixes
    doc = etree.fromstring(parts["word/document.xml"])
    n1 = fix_math_rpr(doc)
    n2 = fix_ppr(doc, W)
    n3 = fix_rpr(doc, W)
    parts["word/document.xml"] = ser(doc)
    print(f"document.xml: math rPr {n1}, pPr {n2}, rPr {n3}")
    fix_settings_inner(parts)
    fix_styles_inner(parts)
    fix_ct_inner(parts)

    # validate
    ok, errs, total = validate(parts["word/document.xml"])
    print(f"XSD validate document.xml: ok={ok}, total_errors={total}")
    for e in errs: print("  ", e.message[:200])

    # write out
    zout = zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED)
    for n, b in parts.items(): zout.writestr(n, b)
    zout.close()
    # $ residue check + oMath count
    z = zipfile.ZipFile(OUT)
    doc = z.read("word/document.xml").decode()
    math_n = doc.count("<m:oMath>")
    dollar = doc.count("$")
    md = open(MD).read()
    md_math = md.count("$$") // 2 + len(re.findall(r"(?<!\$)\\\((.+?)\\\)", md))
    print(f"oMath count: {math_n}; md display-math count: {md.count('$$')//2}; $ residue: {dollar}")

def fix_settings_inner(parts):
    import io
    xml = parts["word/settings.xml"]
    root = etree.fromstring(xml)
    kids = list(root)
    def key(k):
        t = etree.QName(k).localname
        return SETTINGS_ORDER.index(t) if t in SETTINGS_ORDER else 98
    seen, to_remove = set(), []
    for k in kids:
        t = etree.QName(k).localname
        if t == "proofState":
            if "proofState" in seen: to_remove.append(k)
            seen.add("proofState")
    for k in to_remove: root.remove(k)
    kids = list(root)
    skids = sorted(kids, key=key)
    for k in kids: root.remove(k)
    for k in skids: root.append(k)
    parts["word/settings.xml"] = ser(root)

def fix_styles_inner(parts):
    xml = parts["word/styles.xml"]
    root = etree.fromstring(xml)
    n = 0
    for st in root.iter("{%s}style" % W):
        kids = list(st)
        names = [etree.QName(k).localname for k in kids]
        if "qFormat" in names:
            pre = [k for k in kids if etree.QName(k).localname in
                   ("name","aliases","basedOn","next","link","autoRedefine","hidden","uiPriority","semiHidden","unhideWhenUsed")]
            qf = [k for k in kids if etree.QName(k).localname == "qFormat"]
            post = [k for k in kids if k not in pre and k not in qf]
            newkids = pre + qf + post
            if newkids != kids:
                for k in kids: st.remove(k)
                for k in newkids: st.append(k)
                n += 1
    parts["word/styles.xml"] = ser(root)

def fix_ct_inner(parts):
    ct = parts["[Content_Types].xml"].decode()
    add = ""
    if 'Extension="png"' not in ct: add += '<Default Extension="png" ContentType="image/png"/>'
    if 'Extension="jpeg"' not in ct: add += '<Default Extension="jpeg" ContentType="image/jpeg"/>'
    if add:
        ct = ct.replace("</Types>", add + "</Types>")
        parts["[Content_Types].xml"] = ct.encode()

if __name__ == "__main__":
    main()
