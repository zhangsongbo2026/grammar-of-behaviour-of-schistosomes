#!/usr/bin/env python3
"""E11: network layer from STRING v12.0 (real downloads), high-confidence (>=0.7) subnetworks.
Topology descriptors per species."""
import gzip, json, math
import networkx as nx

SPECIES = {
 "6182":"Schistosoma japonicum","6183":"Schistosoma mansoni","6184":"Schistosoma bovis",
 "6185":"Schistosoma haematobium","6186":"Schistosoma curassoni","6188":"Schistosoma rodhaini",
 "31246":"Schistosoma mattheei","48269":"Schistosoma margrebowiei"}

out = {}
for tax, name in SPECIES.items():
    path = f"data/string/{tax}.protein.links.detailed.v12.0.txt.gz"
    nodes, edges_hc, edges_all, wsum = set(), 0, 0, 0.0
    deg = {}
    with gzip.open(path, "rt") as f:
        hdr = f.readline()
        for line in f:
            p = line.rstrip("\n").split(" ")
            a, b = p[0], p[1]
            score = int(p[-1])
            edges_all += 1
            if score >= 700:
                edges_hc += 1
                wsum += score/1000.0
                deg[a] = deg.get(a,0)+1
                deg[b] = deg.get(b,0)+1
                nodes.add(a); nodes.add(b)
    # subsample graph for clustering coefficient (exact on up to ~10k nodes)
    G = nx.Graph()
    with gzip.open(path, "rt") as f:
        f.readline()
        for i, line in enumerate(f):
            p = line.rstrip("\n").split(" ")
            if int(p[-1]) >= 700: G.add_edge(p[0], p[1])
    degs = sorted(dict(G.degree()).values(), reverse=True)
    n = G.number_of_nodes(); m = G.number_of_edges()
    dens = 2*m/(n*(n-1)) if n>1 else 0.0
    # clustering on a random 2000-node induced subgraph if too big
    if n > 4000:
        import random; random.seed(42)
        sub = random.sample(list(G.nodes), 4000)
        cc = nx.average_clustering(G.subgraph(sub))
    else:
        cc = nx.average_clustering(G)
    top = degs[:20]
    out[name] = {
        "taxid": tax, "proteins_hc": n, "edges_hc": m, "density": round(dens,6),
        "mean_degree": round(2*m/n, 3) if n else 0,
        "max_degree": degs[0] if degs else 0, "top20_degree_share": round(sum(top)/max(2*m,1),4),
        "clustering": round(cc,5),
        "power_law_gamma": round(_gamma(degs),3) if (degs:=None) is None else None,
    }
    print(name, out[name], flush=True)

def _gamma(d): pass
json.dump(out, open("results/e11_string_topology.json","w"), indent=1)
